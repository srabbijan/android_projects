package com.example.seatplan;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    TextView textView,ROLL_TV,EXAM_TIME_TV,ROOM_NO_TV,LOCATION_TV,CENTER_TV;
    TextView goToWeb;
    Spinner spinner;
    Button button;
    EditText editText;
    String Unit;
    A a;
    B b;
    C c;
    H h;
    I i;
    ClipboardManager clipboardManager;
    ClipData clipData;
    Vibrator vibrator;
    String ROLL,ROOM,LOCATION,CENTER,EXAMTIME,RESULT;
    A_DB a_Db;
    B_DB b_db;
    C_DB c_db;
    H_DB h_db;
    I_DB i_db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        a_Db = new A_DB(this);
        b_db = new B_DB(this);
        c_db = new C_DB(this);
        h_db = new H_DB(this);
        i_db = new I_DB(this);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ROLL_TV=findViewById(R.id.Roll_No);
        EXAM_TIME_TV=findViewById(R.id.ExamTime);
        ROOM_NO_TV=findViewById(R.id.RoomNo);
        LOCATION_TV= findViewById(R.id.Location);
        CENTER_TV=findViewById(R.id.Center);

        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        textView = findViewById(R.id.wellcomeText);
        textView.setSelected(true);

        clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        goToWeb = findViewById(R.id.officialWebsite);

        spinner = findViewById(R.id.spinerUnit);
        button = findViewById(R.id.search);
        editText = findViewById(R.id.roll);

        a = new A();
        b = new B();
        c = new C();
        h = new H();
        i = new I();

        AddDataAUNIT();
        AddDataBUNIT();
        AddDataCUNIT();
        AddDataHUNIT();
       AddDataIUNIT();

        final String[] units = {"       Select Unit","        Unit A","        Unit B","        Unit C","        Unit H","        Unit I"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,units);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i)
                {
                    case 0:
                        Unit = "Select Unit";
                        break;
                    case 1:
                    { Unit = "A";
                        break;}
                    case 2:
                    {Unit = "B";
                        break;}
                    case 3:
                    {Unit = "C";
                        break;}
                    case 4:
                    {Unit = "H";
                        break;}
                    case 5:
                    {Unit = "I";
                        break;}
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        goToWeb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://admission.bsmrstu.edu.bd/"));
                startActivity(intent);
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int roll=0;
                String s = editText.getText().toString().trim();
                if(s.length()!=0)
                    roll = Integer.parseInt(editText.getText().toString());
                    if(Unit=="Select Unit"){
                        if(Build.VERSION.SDK_INT>=26){
                            vibrator.vibrate(VibrationEffect.createOneShot(200,VibrationEffect.DEFAULT_AMPLITUDE));
                        }
                        else
                            vibrator.vibrate(200);
                        removeText();
                        Toast.makeText(MainActivity.this,"Please Select Unit", Toast.LENGTH_SHORT).show();
                }
                // A Unit
                else if (Unit == "A"){
                    boolean b = chack(s,1,19986,Unit,roll);
                    if(b==true){
                        editText.setText("");
                        ROLL = ""+Unit+s;
                        EXAMTIME = "10/11/2018; 1:00 PM";
                        Cursor res = a_Db.getDataAUNIT(roll);
                        if(res.getCount() == 0) {
                            Toast.makeText(MainActivity.this, "Error\",\"Nothing found", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        while (res.moveToNext()) {
                            ROOM = res.getString(3);
                            LOCATION=res.getString(4);
                            CENTER=res.getString(5);
                        }
                        ROLL_TV.setText(ROLL);
                        EXAM_TIME_TV.setText(EXAMTIME);
                        ROOM_NO_TV.setText(ROOM);
                        LOCATION_TV.setText(LOCATION);
                        CENTER_TV.setText(CENTER);
                        RESULT = "ROLL_NO :"+ROLL+"\nEXAM_TIME :"+EXAMTIME+"\nROOM_NO :"+ROOM+"\nLOCATION :"+
                                LOCATION+"\nCENTER :"+CENTER;
                        closeKeyboard();
                    }
                }
                // B Unit
                else if (Unit == "B"){

                    boolean b = chack(s,1,11500,Unit,roll);
                    if(b==true){
                        editText.setText("");
                        ROLL = ""+Unit+s;
                        EXAMTIME = "10/11/2018; 1:00 PM";
                        Cursor res = b_db.getDataBUNIT(roll);
                        if(res.getCount() == 0) {
                            Toast.makeText(MainActivity.this, "Error\",\"Nothing found", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        while (res.moveToNext()) {
                            ROOM = res.getString(3);
                            LOCATION=res.getString(4);
                            CENTER=res.getString(5);
                        }
                        ROLL_TV.setText(ROLL);
                        EXAM_TIME_TV.setText(EXAMTIME);
                        ROOM_NO_TV.setText(ROOM);
                        LOCATION_TV.setText(LOCATION);
                        CENTER_TV.setText(CENTER);
                        RESULT = "ROLL_NO :"+ROLL+"\nEXAM_TIME :"+EXAMTIME+"\nROOM_NO :"+ROOM+"\nLOCATION :"+
                                LOCATION+"\nCENTER :"+CENTER;
                        closeKeyboard();
                    }
                }
                // C unit
                else if (Unit == "C"){
                    boolean b = chack(s,1,15500,Unit,roll);
                    if(b==true){
                        editText.setText("");
                        ROLL = ""+Unit+s;
                        EXAMTIME = "10/11/2018; 1:00 PM";
                        Cursor res = c_db.getDataCUNIT(roll);
                        if(res.getCount() == 0) {
                            Toast.makeText(MainActivity.this, "Error\",\"Nothing found", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        while (res.moveToNext()) {
                            ROOM = res.getString(3);
                            LOCATION=res.getString(4);
                            CENTER=res.getString(5);
                        }
                        ROLL_TV.setText(ROLL);
                        EXAM_TIME_TV.setText(EXAMTIME);
                        ROOM_NO_TV.setText(ROOM);
                        LOCATION_TV.setText(LOCATION);
                        CENTER_TV.setText(CENTER);
                        RESULT = "ROLL_NO :"+ROLL+"\nEXAM_TIME :"+EXAMTIME+"\nROOM_NO :"+ROOM+"\nLOCATION :"+
                                LOCATION+"\nCENTER :"+CENTER;
                        closeKeyboard();
                    }
                }
                // H Unit
                else if (Unit == "H"){
                    boolean b = chack(s,1,8998,Unit,roll);
                    if(b==true){
                       editText.setText("");
                        ROLL = ""+Unit+s;
                        EXAMTIME = "10/11/2018; 1:00 PM";
                        Cursor res = h_db.getDataHUNIT(roll);
                        if(res.getCount() == 0) {
                            Toast.makeText(MainActivity.this, "Error\",\"Nothing found", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        while (res.moveToNext()) {
                            ROOM = res.getString(3);
                            LOCATION=res.getString(4);
                            CENTER=res.getString(5);
                        }
                        ROLL_TV.setText(ROLL);
                        EXAM_TIME_TV.setText(EXAMTIME);
                        ROOM_NO_TV.setText(ROOM);
                        LOCATION_TV.setText(LOCATION);
                        CENTER_TV.setText(CENTER);
                        RESULT = "ROLL_NO :"+ROLL+"\nEXAM_TIME :"+EXAMTIME+"\nROOM_NO :"+ROOM+"\nLOCATION :"+
                                LOCATION+"\nCENTER :"+CENTER;
                        closeKeyboard();
                    }
                }
                //I Unit
                else if (Unit == "I"){
                    boolean b = chack(s,1,1000,Unit,roll);
                    if(b==true){
                        editText.setText("");
                        ROLL = ""+Unit+s;
                        EXAMTIME = "10/11/2018; 1:00 PM";
                        Cursor res = i_db.getDataIUNIT(roll);
                        if(res.getCount() == 0) {
                            Toast.makeText(MainActivity.this, "Error\",\"Nothing found", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        while (res.moveToNext()) {
                            ROOM = res.getString(3);
                            LOCATION=res.getString(4);
                            CENTER=res.getString(5);
                        }
                        ROLL_TV.setText(ROLL);
                        EXAM_TIME_TV.setText(EXAMTIME);
                        ROOM_NO_TV.setText(ROOM);
                        LOCATION_TV.setText(LOCATION);
                        CENTER_TV.setText(CENTER);
                        RESULT = "ROLL_NO :"+ROLL+"\nEXAM_TIME :"+EXAMTIME+"\nROOM_NO :"+ROOM+"\nLOCATION :"+
                                LOCATION+"\nCENTER :"+CENTER;
                        closeKeyboard();
                    }
                }
            }
        });

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text  = RESULT;
                Toast.makeText(MainActivity.this, RESULT, Toast.LENGTH_SHORT).show();
                clipData = ClipData.newPlainText("text",text);
                clipboardManager.setPrimaryClip(clipData);

            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
            this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_search) {

        }
        else if (id == R.id.nav_myAssociation) {
            Intent intent = new Intent(MainActivity.this,myassociation.class);
            startActivity(intent);
        }
        else if (id == R.id.nav_developer) {
            Toast.makeText(this, "Developer", Toast.LENGTH_SHORT).show();

        }else if (id == R.id.nav_about) {
            Toast.makeText(this, "About", Toast.LENGTH_SHORT).show();
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    private boolean chack(String  pass, int low,int up,String unit,int roll) {
        if(pass.length()==0){
            if(Build.VERSION.SDK_INT>=26){
                vibrator.vibrate(VibrationEffect.createOneShot(200,VibrationEffect.DEFAULT_AMPLITUDE));

            }
            else
                vibrator.vibrate(200);
            removeText();
            Toast.makeText(MainActivity.this, "Roll is not Empty\nPlease Enter Valid Roll.", Toast.LENGTH_SHORT).show();
          //  result.setTextColor(Color.RED);
           // result.setText("Roll is not Empty\nPlease Enter Valid Roll.");
            return false;
        }
        else if(pass.length()<5)
        {
            if(Build.VERSION.SDK_INT>=26){
                vibrator.vibrate(VibrationEffect.createOneShot(200,VibrationEffect.DEFAULT_AMPLITUDE));

            }
            else
                vibrator.vibrate(200);
            int ln = pass.length();
            removeText();
            Toast.makeText(MainActivity.this, "Roll can't be "+ln+" Digit\nPlease Enter 5 Digits Roll.", Toast.LENGTH_SHORT).show();

            //result.setTextColor(Color.RED);
           // result.setText("Roll can't be "+ln+" Digit\nPlease Enter 5 Digits Roll.");
            return false;
        }
        else if(roll>up||roll<low)
        {
            if(Build.VERSION.SDK_INT>=26){
                vibrator.vibrate(VibrationEffect.createOneShot(200,VibrationEffect.DEFAULT_AMPLITUDE));

            }
            else
                vibrator.vibrate(200);
            removeText();
            Toast.makeText(MainActivity.this, ""+unit+" Unit Roll Range: "+low+" - "+up+"\nPlease Enter Right Roll", Toast.LENGTH_SHORT).show();

            // result.setTextColor(Color.RED);
           // result.setText(""+unit+" Unit Roll Range: "+low+" - "+up+"\nPlease Enter Right Roll");
            return false;
        }

        return true;
    }
    private void closeKeyboard(){
        View view = this.getCurrentFocus();
        if(view!=null){
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(),0);
        }
    }
    private void removeText(){
        ROLL_TV.setText("");
        ROOM_NO_TV.setText("");
        EXAM_TIME_TV.setText("");
        CENTER_TV.setText("");
        LOCATION_TV.setText("");
    }
    public  void AddDataAUNIT() {
        a_Db.insertDataAUNIT(1,100,"101","A_1_100","BSMRSTU");
        a_Db.insertDataAUNIT(200,400,"101","A_200_400","BSMRSTU");
    }
    public  void AddDataBUNIT() {
        b_db.insertDataBUNIT(1,100,"101","B_1_100","BSMRSTU");
        b_db.insertDataBUNIT(200,400,"101","B_200_400","BSMRSTU");
    }
    public  void AddDataCUNIT() {
        c_db.insertDataCUNIT(1,100,"101","C_1_100","BSMRSTU");
        c_db.insertDataCUNIT(200,400,"101","C_200_400","BSMRSTU");
    }
    public  void AddDataHUNIT() {
        h_db.insertDataHUNIT(1,100,"101","H_1_100","BSMRSTU");
        h_db.insertDataHUNIT(200,400,"101","H_200_400","BSMRSTU");
    }
    public  void AddDataIUNIT() {
        i_db.insertDataIUNIT(1,100,"101","I_1_100","BSMRSTU");
        i_db.insertDataIUNIT(200,400,"101","I_200_400","BSMRSTU");
    }
}
