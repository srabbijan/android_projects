package com.example.seatplan;

public  class C {

    String findFInstitution(int roll){
        String institution = "C";
        if(roll>=1 &&roll<=8032)
        {
            institution= "BSMRSTU";
        }
        else  if(roll>=8033 &&roll<=8500)
        {
            institution= "Gopalganj Girls High School";
        }
        return institution;
    }

    String findFRoom(int roll){
        String room = "";
        if(roll>=1&&roll<=151)
        {
            room="Bank Varanda (Ground floor)";
        }
        else if(roll>=152&&roll<=307)
        {
            room="Faculty Varanda (Ground floor)";
        }
        else if(roll>=308&&roll<=387)
        {
            room="215";
        }
        else if(roll>=388&&roll<=467)
        {
            room="303";
        }
        else if(roll>=468&&roll<=517)
        {
            room="308";
        }
        else if(roll>=518&&roll<=597)
        {
            room="403";
        }
        else if(roll>=598&&roll<=647)
        {
            room="408";
        }
        else if(roll>=648&&roll<=717)
        {
            room="413";
        }
        else if(roll>=718&&roll<=747)
        {
            room="414";
        }
        else if(roll>=748&&roll<=797)
        {
            room="416";
        }
        else if(roll>=798&&roll<=867)
        {
            room="503";
        }
        else if(roll>=868&&roll<=912)
        {
            room="504";
        }
        else if(roll>=913&&roll<=952)
        {
            room="506";
        }
        else if(roll>=953&&roll<=1032)
        {
            room="513";
        }
        else if(roll>=1033&&roll<=1077)
        {
            room="516";
        }
        else if(roll>=1078&&roll<=1162)
        {
            room="103";
        }
        else if(roll>=1163&&roll<=1257)
        {
            room="104";
        }
        else if(roll>=1258&&roll<=1302)
        {
            room="201";
        }
        else if(roll>=1303&&roll<=1382)
        {
            room="202";
        }
        else if(roll>=1383&&roll<=1462)
        {
            room="203";
        }
        else if(roll>=1463&&roll<=1517)
        {
            room="205";
        }
        else if(roll>=1518&&roll<=1562)
        {
            room="209";
        }
        else if(roll>=1563&&roll<=1597)
        {
            room="302";
        }
        else if(roll>=1598&&roll<=1717)
        {
            room="307";
        }
        else if(roll>=1718&&roll<=1777)
        {
            room="308";
        } else if(roll>=1778&&roll<=1807)
        {
            room="311";
        } else if(roll>=1808&&roll<=1897)
        {
            room="312";
        }
        else if(roll>=1898&&roll<=1952)
        {
            room="401(B)";
        }
        else if(roll>=1953&&roll<=2022)
        {
            room="407(B)";
        }
        else if(roll>=2023&&roll<=2117)
        {
            room="408";
        } else if(roll>=2118&&roll<=2172)
        {
            room="506";
        } else if(roll>=2173&&roll<=2237)
        {
            room="507";
        }
        else if(roll>=2238&&roll<=2297)
        {
            room="508";
        }
        else if(roll>=2298&&roll<=2357)
        {
            room="511";
        }
        else if(roll>=2358&&roll<=2447)
        {
            room="512";
        }
        else if(roll>=2448&&roll<=2627)
        {
            room="101, Hall Room";
        }
        else if(roll>=2628&&roll<=2807)
        {
            room="102, Hall Room";
        } else if(roll>=2808&&roll<=2867)
        {
            room="103";
        } else if(roll>=2868&&roll<=2927)
        {
            room="104";
        } else if(roll>=2928&&roll<=2987)
        {
            room="105";
        }
         else if(roll>=2988&&roll<=3047)
        {
            room="106";
        } else if(roll>=3048&&roll<=3107)
        {
            room="107";
        } else if(roll>=3108&&roll<=3197)
        {
            room="108";
        } else if(roll>=3198&&roll<=3257)
        {
            room="201";
        } else if(roll>=3258&&roll<=3317)
        {
            room="202";
        } else if(roll>=3318&&roll<=3377)
        {
            room="203";
        }
        else if(roll>=3378&&roll<=3437)
        {
            room="204";
        }
        else if(roll>=3438&&roll<=3497)
        {
            room="205";
        } else if(roll>=3498&&roll<=3587)
        {
            room="206";
        } else if(roll>=3588&&roll<=3677)
        {
            room="207";
        } else if(roll>=3678&&roll<=3767)
        {
            room="208";
        } else if(roll>=3768&&roll<=3857)
        {
            room="209";
        } else if(roll>=3858&&roll<=3917)
        {
            room="301";
        } else if(roll>=3918&&roll<=3977)
        {
            room="302";
        } else if(roll>=3978&&roll<=4037)
        {
            room="303";
        } else if(roll>=4038&&roll<=4097)
        {
            room="304";
        } else if(roll>=4098&&roll<=4157)
        {
            room="305";
        } else if(roll>=4158&&roll<=4217)
        {
            room="306";
        } else if(roll>=4218&&roll<=4307)
        {
            room="307";
        } else if(roll>=4308&&roll<=4397)
        {
            room="308";
        } else if(roll>=4398&&roll<=4487)
        {
            room="309";
        } else if(roll>=4488&&roll<=4577)
        {
            room="310";
        } else if(roll>=4578&&roll<=4667)
        {
            room="401";
        } else if(roll>=4668&&roll<=4757)
        {
            room="402";
        } else if(roll>=4758&&roll<=4847)
        {
            room="403";
        } else if(roll>=4848&&roll<=4937)
        {
            room="404";
        } else if(roll>=4938&&roll<=5027)
        {
            room="405";
        } else if(roll>=5028&&roll<=5117)
        {
            room="406";
        } else if(roll>=5118&&roll<=5207)
        {
            room="407";
        } else if(roll>=5208&&roll<=5297)
        {
            room="408";
        } else if(roll>=5298&&roll<=5387)
        {
            room="501";
        } else if(roll>=5388&&roll<=5477)
        {
            room="502";
        } else if(roll>=5478&&roll<=5669)
        {
            room="503,Hall Room";
        } else if(roll>=5670&&roll<=5759)
        {
            room="Computer Browsing Lab";
        } else if(roll>=5760&&roll<=5869)
        {
            room="Library Ground Open Space";
        } else if(roll>=5870&&roll<=6009)
        {
            room="Library 1st Floor Reading Room";
        } else if(roll>=6010&&roll<=6559)
        {
            room="Garage";
        } else if(roll>=6560&&roll<=6649)
        {
            room="101";
        } else if(roll>=6650&&roll<=6739)
        {
            room="102";
        } else if(roll>=6740&&roll<=6829)
        {
            room="103";
        } else if(roll>=6830&&roll<=6900)
        {
            room="104";
        } else if(roll>=6901&&roll<=6970)
        {
            room="105";
        }
        else if(roll>=6971&&roll<=7050)
        {
            room="106";
        } else if(roll>=7051&&roll<=7111)
        {
            room="107";
        } else if(roll>=7112&&roll<=7201)
        {
            room="108";
        } else if(roll>=7202&&roll<=7291)
        {
            room="109";
        } else if(roll>=7292&&roll<=7492)
        {
            room="Hall Room";
        } else if(roll>=7493&&roll<=7582)
        {
            room="101";
        } else if(roll>=7583&&roll<=7672)
        {
            room="102";
        } else if(roll>=7673&&roll<=7712)
        {
            room="103";
        } else if(roll>=7713&&roll<=7752)
        {
            room="104";
        } else if(roll>=7753&&roll<=7792)
        {
            room="105";
        } else if(roll>=7793&&roll<=7832)
        {
            room="106";
        } else if(roll>=7833&&roll<=7872)
        {
            room="107";
        } else if(roll>=7873&&roll<=7912)
        {
            room="108";
        } else if(roll>=7913&&roll<=7952)
        {
            room="109";
        } else if(roll>=7953&&roll<=7992)
        {
            room="110";
        } else if(roll>=7993&&roll<=8032)
        {
            room="111";
        } else if(roll>=8033&&roll<=8105)
        {
            room="101";
        } else if(roll>=8107&&roll<=8154)
        {
            room="102";
        } else if(roll>=8155&&roll<=8227)
        {
            room="103";
        } else if(roll>=8228&&roll<=8304)
        {
            room="104";
        } else if(roll>=8305&&roll<=8390)
        {
            room="105";
        } else if(roll>=8391&&roll<=8427)
        {
            room="106";
        } else if(roll>=8428&&roll<=8463)
        {
            room="107";
        } else if(roll>=8464&&roll<=8500)
        {
            room="208";
        }

        return room;
    }

    String findFBuilding(int roll) {
        String building = "";
        if(roll>=1&&roll<=1077){
            building = "Administrative Building";
        }
        else if(roll>=1078&&roll<=2447)
        {
            building="Academic Building";
        }  else if(roll>=2448&&roll<=5669)
        {
            building="Academic Building (New)";
        }  else if(roll>=5670&&roll<=6009)
        {
            building="Library";
        }  else if(roll>=6010&&roll<=6559)
        {
            building="University Garage";
        }  else if(roll>=6560&&roll<=6970)
        {
            building="Bangabandhu University School and College (Tin Shed 1: Near Library)";
        }  else if(roll>=6971&&roll<=7291)
        {
            building="Bangabandhu University School and College (Tin Shed 2: Near Library)";
        }  else if(roll>=7292&&roll<=8032)
        {
            building="Bangabandhu University School and College (Near VC Residence)";
        }  else if(roll>=8033&&roll<=8500)
        {
            building="Gopalganj Girls High School";
        }
        return building;
    }
}