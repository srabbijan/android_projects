package com.example.seatplan;

public class I {
    String findGInstitution(int roll){
        String institution = "BSMRSTU";
        return institution;
    }
    String findGRoom(int roll){
        String room = "";
        if(roll>=1&&roll<=85)
        {
            room = "103";
        }
        else if(roll>=86&&roll<=180)
        {
            room = "104";
        }
 else if(roll>=181&&roll<=225)
        {
            room = "201";
        }
else if(roll>=226&&roll<=305)
        {
            room = "202";
        }
else if(roll>=306&&roll<=385)
        {
            room = "203";
        }
else if(roll>=386&&roll<=440)
        {
            room = "205";
        }
else if(roll>=441&&roll<=485)
        {
            room = "209";
        }
else if(roll>=486&&roll<=541)
        {
            room = "302";
        }
else if(roll>=542&&roll<=728)
        {
            room = "307";
        }
else if(roll>=732&&roll<=837)
        {
            room = "308";
        }
else if(roll>=838&&roll<=892)
        {
            room = "311";
        }
else if(roll>=893&&roll<=1000)
        {
            room = "312";
        }


        return room;
    }
    String findGBuilding(int roll){
        String building = "Academic Building";
        return building;
    }
}
