package com.example.seatplan;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomAdapter extends BaseExpandableListAdapter {
    private Context context;
    private ArrayList<GroupInfo> childtitles;
    public CustomAdapter(Context context, ArrayList<GroupInfo> childtitles){
        this.context =context;
        this.childtitles = childtitles;
    }
    @Override
    public int getGroupCount() {
        return childtitles.size();
    }

    @Override
    public int getChildrenCount(int i) {
        ArrayList<ChildInfo> list = childtitles.get(i).getProductList();
        return list.size();
    }

    @Override
    public Object getGroup(int i) {
        return childtitles.get(i);
    }

    @Override
    public Object getChild(int i, int i1) {
        ArrayList<ChildInfo> list = childtitles.get(i).getProductList();
        return list.get(i1);
    }

    @Override
    public long getGroupId(int i) {
        return i;
    }

    @Override
    public long getChildId(int i, int i1) {
        return i1;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getGroupView(int i, boolean b, View view, ViewGroup viewGroup) {
        GroupInfo  listTile =(GroupInfo) getGroup(i);
        if(view == null)
        {
            LayoutInflater layoutInflater =(LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = layoutInflater.inflate(R.layout.group_header,null);
        }
        TextView listTiteTextView = (TextView) view.findViewById(R.id.title);
        listTiteTextView.setText(listTile.getName().trim());
        return  view;
    }

    @Override
    public View getChildView(int i, int i1, boolean b, View view, ViewGroup viewGroup) {
        ChildInfo expandedListText = (ChildInfo) getChild(i,i1);
        if(view == null){
            LayoutInflater layoutInflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view= layoutInflater.inflate(R.layout.child_item,null);
        }
        TextView expandListTextView = view.findViewById(R.id.childItem);
        expandListTextView.setText(expandedListText.getName().trim());
        return view;
    }

    @Override
    public boolean isChildSelectable(int i, int i1) {
        return true;
    }
}
