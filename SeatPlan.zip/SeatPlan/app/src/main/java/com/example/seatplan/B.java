package com.example.seatplan;

public class B {
    String findEInstitution(int roll){
        String institution = "B";
        if(roll>=1&&roll<=8203){
            institution = "BSMRSTU";
        }
        else if(roll>=8204&&roll<=10863){
            institution = "Govt. Bangabandhu College, Gopalganj";
        }
        else if(roll>=10864&&roll<=12163){
            institution = "Sheikh Hasina Govt. Girls High School";
        }
        else if(roll>=12164&&roll<=12977){
            institution = "Sarnakoli High School, Gopalganj";
        }
        else if(roll>=12978&&roll<=14283){
            institution = "Sheikh Fazilatun-nesa Govt. Mohila College";
        }
        else if(roll>=14284&&roll<=14747){
            institution = "Gopalganj Girls High School";
        }
        else if(roll>=14748&&roll<=15269){
            institution = "Technical School and College, Gopalganj";
        }
        else if(roll>=15270&&roll<=16105){
            institution = "Jugoshikha Girls School";
        }

        else if(roll>=16106&&roll<=17783){
            institution = "Hazi Lal Mia City College, Gopalganj";
        }
        else if(roll>=17784&&roll<=19015){
            institution = "S.M. Model Govt. High School";
        }
        else if(roll>=19016&&roll<=20160){
            institution = "Binapani Govt. Girls High School";
        }
        else if(roll>=20161&&roll<=20847){
            institution = "Gopalganj Mohila Kamil Model Madrasah";
        }
        else if(roll>=20848&&roll<=21497){
            institution = "Salehia Kamil Madrasah (Alia Madrasah)";
        }

        return institution;
    }

    String findERoom(int roll){
        String room = "";
        if(roll>=1&&roll<=165){
            room = "Bank Varanda (Ground floor)";
        }
        else if(roll>=166&&roll<=330){
            room = "Faculty Varanda (Ground floor)";
        }else if(roll>=331&&roll<=410){
            room = "215";
        }
        else if(roll>=411&&roll<=491){
            room = "303";
        }
        else if(roll>=492&&roll<=541){
            room = "308";
        }
        else if(roll>=542&&roll<=621){
            room = "403";
        }
        else if(roll>=622&&roll<=672){
            room = "408";
        }
        else if(roll>=673&&roll<=742){
            room = "413";
        }
        else if(roll>=743&&roll<=772){
            room = "414";
        }
        else if(roll>=773&&roll<=822){
            room = "416";
        }
        else if(roll>=823&&roll<=892){
            room = "503";
        }
        else if(roll>=893&&roll<=937){
            room = "504";
        }
        else if(roll>=938&&roll<=977){
            room = "506";
        }
        else if(roll>=978&&roll<=1057){
            room = "513";
        }
        else if(roll>=1058&&roll<=1102){
            room = "516";
        }
        else if(roll>=1103&&roll<=1233){
            room = "Varanda (Ground floor),infront of Pharmacy Lab";
        }
        else if(roll>=1234&&roll<=1318){
            room = "103";
        }
        else if(roll>=1319&&roll<=1413){
            room = "104";
        }
        else if(roll>=1414&&roll<=1458){
            room = "201";
        }
        else if(roll>=1459&&roll<=1538){
            room = "202";
        }
        else if(roll>=1539&&roll<=1618){
            room = "203";
        }
        else if(roll>=1619&&roll<=1673){
            room = "205";
        }
        else if(roll>=1674&&roll<=1718){
            room = "209";
        }
        else if(roll>=1719&&roll<=1753){
            room = "302";
        }
        else if(roll>=1754&&roll<=1873){
            room = "307";
        }
        else if(roll>=1874&&roll<=1933){
            room = "308";
        }
        else if(roll>=1934&&roll<=1963){
            room = "311";
        }
        else if(roll>=1964&&roll<=2053){
            room = "312";
        }
        else if(roll>=2054&&roll<=2108){
            room = "401(B)";
        }
        else if(roll>=2109&&roll<=2178){
            room = "407(B)";
        }
        else if(roll>=2179&&roll<=2273){
            room = "408";
        }
        else if(roll>=2274&&roll<=2328){
            room = "506";
        }
        else if(roll>=2329&&roll<=2393){
            room = "507";
        }
        else if(roll>=2394&&roll<=2453){
            room = "508";
        }
        else if(roll>=2454&&roll<=2513){
            room = "511";
        }
        else if(roll>=2514&&roll<=2603){
            room = "512";
        }
        else if(roll>=2604&&roll<=2793){
            room = "101, Hall Room";
        }
        else if(roll>=2794&&roll<=2983){
            room = "102, Hall Room";
        }
        else if(roll>=2984&&roll<=3043) {
            room = "103";
        }
        else if(roll>=3044&&roll<=3103) {
            room = "104";
        }
        else if(roll>=3104&&roll<=3163) {
            room = "105";
        }
        else if(roll>=3164&&roll<=3223) {
            room = "106";
        }
        else if(roll>=3224&&roll<=3283) {
            room = "107";
        }
        else if(roll>=3284&&roll<=3373) {
            room = "108";
        }
        else if(roll>=3374&&roll<=3433) {
            room = "201";
        }
        else if(roll>=3434&&roll<=3493) {
            room = "202";
        }
        else if(roll>=3494&&roll<=3553) {
            room = "203";
        }
        else if(roll>=3554&&roll<=3613) {
            room = "204";
        }
        else if(roll>=3614&&roll<=3673) {
            room = "205";
        }
        else if(roll>=3674&&roll<=3763) {
            room = "206";
        }
        else if(roll>=3764&&roll<=3853) {
            room = "207";
        }
        else if(roll>=3854&&roll<=3943) {
            room = "208";
        }
        else if(roll>=3944&&roll<=4033) {
            room = "209";
        }
        else if(roll>=4034&&roll<=4093) {
            room = "301";
        }
        else if(roll>=4094&&roll<=4153) {
            room = "302";
        }
        else if(roll>=4154&&roll<=4213) {
            room = "303";
        }
        else if(roll>=4214&&roll<=4273) {
            room = "304";
        }
        else if(roll>=4274&&roll<=4333) {
            room = "305";
        }
        else if(roll>=4334&&roll<=4393) {
            room = "306";
        }
        else if(roll>=4394&&roll<=4483) {
            room = "307";
        }
        else if(roll>=4484&&roll<=4573) {
            room = "308";
        }
        else if(roll>=4574&&roll<=4663) {
            room = "309";
        }
        else if(roll>=4664&&roll<=4753) {
            room = "310";
        }
        else if(roll>=4754&&roll<=4843) {
            room = "401";
        }
        else if(roll>=4844&&roll<=4933) {
            room = "402";
        }
        else if(roll>=4934&&roll<=5023) {
            room = "403";
        }
        else if(roll>=5024&&roll<=5113) {
            room = "404";
        }
        else if(roll>=5114&&roll<=5203) {
            room = "405";
        }
        else if(roll>=5204&&roll<=5293) {
            room = "406";
        }
        else if(roll>=5294&&roll<=5383) {
            room = "407";
        }
        else if(roll>=5384&&roll<=5473) {
            room = "408";
        }
        else if(roll>=5474&&roll<=5563) {
            room = "501";
        }
        else if(roll>=5564&&roll<=5653) {
            room = "502";
        }
        else if(roll>=5654&&roll<=5843) {
            room = "503,Hall Room";
        }
        else if(roll>=5844&&roll<=5933) {
            room = "Computer Browsing Lab";
        }
        else if(roll>=5934&&roll<=6043) {
            room = "Library Ground Open Space";
        }
        else if(roll>=6044&&roll<=6183) {
            room = "Library 1st Floor Reading Room";
        }
        else if(roll>=6184&&roll<=6733) {
            room = "Garage";
        }
        else if(roll>=6734&&roll<=6823) {
            room = "101";
        }
        else if(roll>=6824&&roll<=6913) {
            room = "102";
        }
        else if(roll>=6914&&roll<=7003) {
            room = "103";
        }
        else if(roll>=7004&&roll<=7073) {
            room = "104";
        }
        else if(roll>=7074&&roll<=7143) {
            room = "105";
        }
        else if(roll>=7144&&roll<=7223) {
            room = "106";
        }
        else if(roll>=7224&&roll<=7283) {
            room = "107";
        }
        else if(roll>=7284&&roll<=7373) {
            room = "108";
        }
        else if(roll>=7374&&roll<=7463) {
            room = "109";
        }
        else if(roll>=7464&&roll<=7663) {
            room = "Hall Room";
        }
        else if(roll>=7664&&roll<=7753) {
            room = "101";
        }
        else if(roll>=7754&&roll<=7843) {
            room = "102";
        }
        else if(roll>=7844&&roll<=7883) {
            room = "103";
        }
        else if(roll>=7884&&roll<=7923) {
            room = "104";
        }
        else if(roll>=7924&&roll<=7963) {
            room = "105";
        }
        else if(roll>=7964&&roll<=8003) {
            room = "106";
        }
        else if(roll>=8004&&roll<=8043) {
            room = "107";
        }
        else if(roll>=8044&&roll<=8083) {
            room = "108";
        }
        else if(roll>=8084&&roll<=8123) {
            room = "109";
        }
        else if(roll>=8124&&roll<=8163) {
            room = "110";
        }
        else if(roll>=8164&&roll<=8203) {
            room = "111";
        }
        else if(roll>=8204&&roll<=8373) {
            room = "1001";
        }
        else if(roll>=8374&&roll<=8543) {
            room = "1002";
        }
        else if(roll>=8544&&roll<=8643) {
            room = "2001";
        }
        else if(roll>=8644&&roll<=8743) {
            room = "2002";
        }
        else if(roll>=8744&&roll<=8838) {
            room = "2003";
        }
        else if(roll>=8839&&roll<=8928) {
            room = "2004";
        }
        else if(roll>=8929&&roll<=9018) {
            room = "3001";
        }
        else if(roll>=9019&&roll<=9093) {
            room = "3004";
        }
        else if(roll>=9094&&roll<=9153) {
            room = "4001";
        }
        else if(roll>=9154&&roll<=9203) {
            room = "4004";
        }
        else if(roll>=9204&&roll<=9373) {
            room = "5001";
        }
        else if(roll>=9374&&roll<=9463) {
            room = "102";
        }
        else if(roll>=9464&&roll<=9523) {
            room = "104";
        }
        else if(roll>=9524&&roll<=9613) {
            room = "105";
        }
        else if(roll>=9614&&roll<=9703) {
            room = "106";
        }
        else if(roll>=9704&&roll<=9798) {
            room = "202";
        }
        else if(roll>=9799&&roll<=9863) {
            room = "203";
        }
        else if(roll>=9864&&roll<=9953) {
            room = "205";
        }
        else if(roll>=9954&&roll<=10043) {
            room = "206";
        }
        else if(roll>=10044&&roll<=10113) {
            room = "302";
        }
        else if(roll>=10114&&roll<=10203) {
            room = "303";
        }
        else if(roll>=10204&&roll<=10293) {
            room = "305";
        }
        else if(roll>=10294&&roll<=10388) {
            room = "306";
        }
        else if(roll>=10389&&roll<=10448) {
            room = "402";
        }
        else if(roll>=10449&&roll<=10583) {
            room = "403";
        }
        else if(roll>=10584&&roll<=10678) {
            room = "405";
        }
        else if(roll>=10679&&roll<=10773) {
            room = "406";
        }
        else if(roll>=10774&&roll<=10863) {
            room = "Girl's Common Room";
        }


        else if(roll>=10864&&roll<=10928) {
            room = "101";
        }
        else if(roll>=10929&&roll<=10993) {
            room = "102";
        }
        else if(roll>=10994&&roll<=11058) {
            room = "103";
        }
        else if(roll>=11059&&roll<=11188) {
            room = "104";
        }
        else if(roll>=11189&&roll<=11253) {
            room = "201";
        }
        else if(roll>=11254&&roll<=11318) {
            room = "202";
        }
        else if(roll>=11319&&roll<=11383) {
            room = "203";
        }
        else if(roll>=11384&&roll<=11448) {
            room = "204";
        }
        else if(roll>=11449&&roll<=11513) {
            room = "205";
        }
        else if(roll>=11514&&roll<=11578) {
            room = "206";
        }
        else if(roll>=11579&&roll<=11643) {
            room = "301";
        }
        else if(roll>=11644&&roll<=11708) {
            room = "302";
        }
        else if(roll>=11709&&roll<=11773) {
            room = "303";
        }
        else if(roll>=11774&&roll<=11838) {
            room = "304";
        }
        else if(roll>=11839&&roll<=11903) {
            room = "305";
        }
        else if(roll>=11904&&roll<=11968) {
            room = "306";
        }
        else if(roll>=11969&&roll<=12033) {
            room = "401";
        }
        else if(roll>=12034&&roll<=12098) {
            room = "403";
        }
        else if(roll>=12099&&roll<=12163) {
            room = "404";
        }
        else if(roll>=12164&&roll<=12203) {
            room = "01";
        }
        else if(roll>=12204&&roll<=12243) {
            room = "02";
        }
        else if(roll>=12244&&roll<=12293) {
            room = "03";
        }
        else if(roll>=12294&&roll<=12328) {
            room = "105";
        }
        else if(roll>=12329&&roll<=12363) {
            room = "106";
        }
        else if(roll>=12364&&roll<=12401) {
            room = "201";
        }
        else if(roll>=12402&&roll<=12439) {
            room = "202";
        }
        else if(roll>=12440&&roll<=12477) {
            room = "203";
        }
        else if(roll>=12478&&roll<=12515) {
            room = "301";
        }
        else if(roll>=12516&&roll<=12553) {
            room = "302";
        }
        else if(roll>=12554&&roll<=12618) {
            room = "303";
        }
        else if(roll>=12619&&roll<=12656) {
            room = "304";
        }
        else if(roll>=12657&&roll<=12694) {
            room = "305";
        }
        else if(roll>=12695&&roll<=12729) {
            room = "101";
        }
        else if(roll>=12730&&roll<=12764) {
            room = "102";
        }
        else if(roll>=12765&&roll<=12802) {
            room = "103";
        }
        else if(roll>=12803&&roll<=12837) {
            room = "101";
        }
        else if(roll>=12838&&roll<=12872) {
            room = "102";
        }
        else if(roll>=12873&&roll<=12907) {
            room = "201";
        }
        else if(roll>=12908&&roll<=12977) {
            room = "Hall Room";
        }
        else if(roll>=12978&&roll<=13072){
            room = "(4th Floor)";
        }
        else if(roll>=13073&&roll<=13167){
            room = "(4th Floor)";
        }
        else if(roll>=13168&&roll<=13282){
            room = "112";
        }
        else if(roll>=13283&&roll<=13342){
            room = "201";
        }
        else if(roll>=13343&&roll<=13402){
            room = "301";
        }
        else if(roll>=13403&&roll<=13487){
            room = "304";
        }
        else if(roll>=13488&&roll<=13572){
            room = "401";
        }
        else if(roll>=13573&&roll<=13657){
            room = "404";
        }
        else if(roll>=13658&&roll<=13715){
            room = "105";
        }else if(roll>=13716&&roll<=13773){
            room = "106";
        }
        else if(roll>=13774&&roll<=13833){
            room = "107";
        }
        else if(roll>=13834&&roll<=13893){
            room = "108";
        }
        else if(roll>=13894&&roll<=13933){
            room = "501";
        }
        else if(roll>=13934&&roll<=13973){
            room = "502";
        }
        else if(roll>=13974&&roll<=14013){
            room = "601";
        }
        else if(roll>=14014&&roll<=14053){
            room = "602";
        }
        else if(roll>=14054&&roll<=14148){
            room = "701";
        }
        else if(roll>=14149&&roll<=14243){
            room = "801";
        }
        else if(roll>=14244&&roll<=14283){
            room = "802";
        }


        else if(roll>=14284&&roll<=14351)
        {
            room="101";
        }  else if(roll>=14352&&roll<=14396)
        {
            room="102";
        }  else if(roll>=14397&&roll<=14464)
        {
            room="103";
        }  else if(roll>=14465&&roll<=14532)
        {
            room="104";
        }  else if(roll>=14533&&roll<=14607)
        {
            room="105";
        }  else if(roll>=14608&&roll<=14642)
        {
            room="106";
        }  else if(roll>=14643&&roll<=14677)
        {
            room="107";
        }  else if(roll>=14678&&roll<=14712)
        {
            room="208";
        }  else if(roll>=14713&&roll<=14747)
        {
            room="209";
        }  else if(roll>=14748&&roll<=14804)
        {
            room="Room-104";
        }  else if(roll>=14805&&roll<=14879)
        {
            room="Room-112";
        }  else if(roll>=14880&&roll<=14941)
        {
            room="Room-115";
        }  else if(roll>=14942&&roll<=14998)
        {
            room="Room-205";
        }  else if(roll>=14999&&roll<=15103)
        {
            room="Room-206";
        }  else if(roll>=15104&&roll<=15145)
        {
            room="Room-207";
        }  else if(roll>=15146&&roll<=15207)
        {
            room="Room-2001";
        }  else if(roll>=15208&&roll<=15269)
        {
            room="Room-2002";
        }  else if(roll>=15270&&roll<=15331)
        {
            room="Room 01";
        }  else if(roll>=15332&&roll<=15393)
        {
            room="Room 02";
        }  else if(roll>=15394&&roll<=15455)
        {
            room="Room 03";
        }  else if(roll>=15456&&roll<=15517)
        {
            room="Room 04";
        }  else if(roll>=15518&&roll<=15579)
        {
            room="Room 05";
        }  else if(roll>=15580&&roll<=15641)
        {
            room="Room 06";
        }  else if(roll>=15642&&roll<=15703)
        {
            room="Room 07";
        }  else if(roll>=15704&&roll<=15750)
        {
            room="Room 08";
        }  else if(roll>=15751&&roll<=15880)
        {
            room="Room 09";
        }  else if(roll>=15881&&roll<=16030)
        {
            room="Room 10";
        }  else if(roll>=16031&&roll<=16105)
        {
            room="Room 11";
        }
        else if(roll>=16106&&roll<=16190)
        {
            room="06";
        }  else if(roll>=16191&&roll<=16275)
        {
            room="07";
        }  else if(roll>=16276&&roll<=16400)
        {
            room="08";
        }  else if(roll>=16401&&roll<=16462)
        {
            room="09";
        }  else if(roll>=16463&&roll<=16587)
        {
            room="10";
        }  else if(roll>=16588&&roll<=16649)
        {
            room="20";
        }  else if(roll>=16650&&roll<=16711)
        {
            room="21";
        }  else if(roll>=16712&&roll<=16773)
        {
            room="204";
        }  else if(roll>=16774&&roll<=16913)
        {
            room="205";
        }  else if(roll>=16914&&roll<=16975)
        {
            room="304";
        }  else if(roll>=16976&&roll<=17037)
        {
            room="305";
        }  else if(roll>=17038&&roll<=17122)
        {
            room="ICT Room";
        }  else if(roll>=17123&&roll<=17272)
        {
            room="16";
        }  else if(roll>=17273&&roll<=17432)
        {
            room="17";
        }  else if(roll>=17433&&roll<=17512)
        {
            room="18";
        }  else if(roll>=17513&&roll<=17593)
        {
            room="19";
        }  else if(roll>=17594&&roll<=17783)
        {
            room="Hall Room";
        }  else if(roll>=17784&&roll<=17863)
        {
            room="01";
        }  else if(roll>=17864&&roll<=17943)
        {
            room="02";
        }  else if(roll>=17944&&roll<=18024)
        {
            room="03";
        }  else if(roll>=18025&&roll<=18086)
        {
            room="04";
        }  else if(roll>=18087&&roll<=18181)
        {
            room="05";
        }  else if(roll>=18182&&roll<=18228)
        {
            room="06";
        }  else if(roll>=18229&&roll<=18323)
        {
            room="07";
        }  else if(roll>=18324&&roll<=18385)
        {
            room="08";
        }  else if(roll>=18386&&roll<=18480)
        {
            room="09";
        }  else if(roll>=18481&&roll<=18542)
        {
            room="10";
        }  else if(roll>=18543&&roll<=18622)
        {
            room="11";
        }  else if(roll>=18623&&roll<=18767)
        {
            room="12";
        }  else if(roll>=18768&&roll<=18829)
        {
            room="13";
        }  else if(roll>=18830&&roll<=18891)
        {
            room="14";
        }  else if(roll>=18892&&roll<=18953)
        {
            room="15";
        }  else if(roll>=18954&&roll<=19015)
        {
            room="16";
        }  else if(roll>=19016&&roll<=19095)
        {
            room="107";
        }  else if(roll>=19096&&roll<=19160)
        {
            room="108";
        }  else if(roll>=19161&&roll<=19240)
        {
            room="109";
        }  else if(roll>=19241&&roll<=19295)
        {
            room="110";
        }  else if(roll>=19296&&roll<=19345)
        {
            room="111";
        }  else if(roll>=19346&&roll<=19440)
        {
            room="112";
        }  else if(roll>=19441&&roll<=19488)
        {
            room="113";
        }  else if(roll>=19489&&roll<=19553)
        {
            room="201";
        }  else if(roll>=19554&&roll<=19618)
        {
            room="202";
        }  else if(roll>=19619&&roll<=19683)
        {
            room="203";
        }  else if(roll>=19684&&roll<=19733)
        {
            room="204";
        }  else if(roll>=19734&&roll<=19771)
        {
            room="205";
        }  else if(roll>=19772&&roll<=19818)
        {
            room="206";
        }  else if(roll>=19819&&roll<=19880)
        {
            room="208";
        }  else if(roll>=19881&&roll<=19960)
        {
            room="209";
        }  else if(roll>=19961&&roll<=20016)
        {
            room="210";
        }  else if(roll>=20017&&roll<=20041)
        {
            room="Primanry Room 01";
        }  else if(roll>=20042&&roll<=20061)
        {
            room="Primanry Room 02";
        }  else if(roll>=20062&&roll<=20081)
        {
            room="Primanry Room 03";
        }  else if(roll>=20082&&roll<=20101)
        {
            room="Primanry Room 04";
        }  else if(roll>=20102&&roll<=20121)
        {
            room="Primanry Room 05";
        }  else if(roll>=20122&&roll<=20141)
        {
            room="Primanry Room 06";
        }  else if(roll>=20142&&roll<=20160)
        {
            room="Primanry Room 07";
        }  else if(roll>=20161&&roll<=20220)
        {
            room="101";
        }  else if(roll>=20221&&roll<=20280)
        {
            room="102";
        }  else if(roll>=20281&&roll<=20340)
        {
            room="103";
        }  else if(roll>=20341&&roll<=20385)
        {
            room="104";
        }  else if(roll>=20386&&roll<=20430)
        {
            room="105";
        }  else if(roll>=20431&&roll<=20505)
        {
            room="106";
        }  else if(roll>=20506&&roll<=20547)
        {
            room="107";
        }  else if(roll>=20548&&roll<=20589)
        {
            room="108";
        }  else if(roll>=20590&&roll<=20631)
        {
            room="109";
        }  else if(roll>=20632&&roll<=20673)
        {
            room="110";
        }  else if(roll>=20674&&roll<=20718)
        {
            room="111";
        }  else if(roll>=20719&&roll<=20763)
        {
            room="112";
        }  else if(roll>=20764&&roll<=20805)
        {
            room="113";
        }  else if(roll>=20806&&roll<=20847)
        {
            room="114";
        }  else if(roll>=20848&&roll<=20906)
        {
            room="01";
        }  else if(roll>=20907&&roll<=20928)
        {
            room="02";
        }  else if(roll>=20929&&roll<=20950)
        {
            room="03";
        }  else if(roll>=20951&&roll<=21025)
        {
            room="04";
        }  else if(roll>=21027&&roll<=21191)
        {
            room="05";
        }  else if(roll>=21199&&roll<=21352)
        {
            room="06";
        }  else if(roll>=21363&&roll<=21497)
        {
            room="07";
        }

        return room;
    }

    String findEBuilding(int roll){
        String building = "";
        if(roll>=1&&roll<=1102){
            building = "Administrative Building";
        }
        else if(roll>=1103&&roll<=2603){
            building = "Academic Building";
        }
        else if(roll>=2604&&roll<=5843){
            building = "Academic Building (New)";
        }
        else if(roll>=5844&&roll<=6183){
            building = "Library";
        }
        else if(roll>=6184&&roll<=6733){
            building = "University Garage";
        }
        else if(roll>=6734&&roll<=7143){
            building = "Bangabandhu University School & College (Tin Shed 1: Near Library)";
        }
        else if(roll>=7144&&roll<=7463){
            building = "Bangabandhu University School & College (Tin Shed 2: Near Library)";
        }
        else if(roll>=7464&&roll<=8203){
            building = "Bangabandhu University School & College (Near VC Residence)";
        }
        else if(roll>=12164&&roll<=12293){
            building = "Tin Shed Building";
        }
        else if(roll>=12294&&roll<=12694){
            building = "Academic Building-1";
        }
        else if(roll>=12695&&roll<=12802){
            building = "Academic Building-2";
        }
        else if(roll>=12803&&roll<=12907){
            building = "Academic Building-3";
        }
        else if(roll>=12978&&roll<=13072){
            building = "Admin Building- 1";
        }
        else if(roll>=13073&&roll<=13167){
            building = "Admin Building- 2";
        }
        else if(roll>=13168&&roll<=13657){
            building = "Science Building";
        }
        else if(roll>=13658&&roll<=13893){
            building = "Arts Building";
        }
        else if(roll>=13894&&roll<=14283){
            building = "Honours Building";
        }
        else if(roll>=14748&&roll<=15145){
            building = "Administrative Building";
        }
        else if(roll>=15146&&roll<=15269){
            building = "Diploma Building";
        }
        else if(roll>=16106&&roll<=16400){
            building = "Luthfor Rahman Bhabon";
        }
        else if(roll>=16401&&roll<=16587){
            building = "Sabura Rahman Bhabon";
        }
        else if(roll>=16588&&roll<=16711){
            building = "Elias Rahman Bhabon";
        }
        else if(roll>=16712&&roll<=17037){
            building = "Sobura Rahman Bhabon";
        }
        else if(roll>=17038&&roll<=17122){
            building = "Elias Rahman Bhabon";
        }

        else if(roll>=17123&&roll<=17593){
            building = "Banijya Bhaban";
        }
        return building;
    }
}