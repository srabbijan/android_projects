package com.example.seatplan;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class H_DB extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "SeatPlanH.db";
    public static final String TABLE_NAME_H = "H_Unit";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "ROLL_NO_LOW";
    public static final String COL_3 = "ROLL_NO_HIGH";
    public static final String COL_4 = "ROOM_NO";
    public static final String COL_5 = "LOCATION";
    public static final String COL_6 = "CENTER";
    public H_DB(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase a) {
        a.execSQL("create table " + TABLE_NAME_H+" (ID INTEGER PRIMARY KEY AUTOINCREMENT,ROLL_NO_LOW INTEGER,ROLL_NO_HIGH INTEGER,ROOM_NO TEXT,LOCATION TEXT,CENTER TEXT)");
    }
    @Override
    public void onUpgrade(SQLiteDatabase a, int oldVersion, int newVersion) {
        a.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME_H);
        onCreate(a);
    }
    public void insertDataHUNIT(Integer rollNoLow,Integer rollNoHigh,String roomNo,String location,String center) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2,rollNoLow);
        contentValues.put(COL_3,rollNoHigh);
        contentValues.put(COL_4,roomNo);
        contentValues.put(COL_5,location);
        contentValues.put(COL_6,center);
        db.insert(TABLE_NAME_H,null ,contentValues);
    }
    public Cursor getDataHUNIT(int roll) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery(" SELECT *FROM "+TABLE_NAME_H+ " WHERE "+ roll+" BETWEEN "+COL_2+ " AND "+COL_3,null);
        return res;
    }

}
