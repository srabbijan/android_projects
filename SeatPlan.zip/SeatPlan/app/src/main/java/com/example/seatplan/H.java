package com.example.seatplan;

public class H {
    String findGInstitution(int roll){
        String institution = "";
        if(roll>=1&&roll<=8307){
            institution = "BSMRSTU";
        }
        else  if(roll>=8308&&roll<=8998){
            institution = "Technical School and College,Gopalganj";
        }
        return institution;
    }

    String findGRoom(int roll){
        String room = "";
        if(roll>=1&&roll<=170)
        {
            room = "Bank Varanda (Ground floor)";
        }
        else if(roll>=171&&roll<=340)
        {
            room = "Faculty Varanda (Ground floor)";
        }
        else if(roll>=341&&roll<=422)
        {
            room = "215";
        }
        else if(roll>=423&&roll<=504)
        {
            room = "303";
        }
        else if(roll>=505&&roll<=554)
        {
            room = "308";
        }
        else if(roll>=555&&roll<=636)
        {
            room = "403";
        }
        else if(roll>=637&&roll<=687)
        {
            room = "408";
        }
        else if(roll>=688&&roll<=757)
        {
            room = "413";
        }
        else if(roll>=758&&roll<=787)
        {
            room = "414";
        }
        else if(roll>=788&&roll<=837)
        {
            room = "416";
        }
        else if(roll>=838&&roll<=907)
        {
            room = "503";
        }
        else if(roll>=908&&roll<=952)
        {
            room = "504";
        }
        else if(roll>=953&&roll<=992)
        {
            room = "506";
        }
        else if(roll>=993&&roll<=1074)
        {
            room = "513";
        }
        else if(roll>=1075&&roll<=1119)
        {
            room = "516";
        }else if(roll>=1120&&roll<=1251)
        {
            room = "Varanda (Ground floor), infront of Pharmacy Lab";
        }
else if(roll>=1252&&roll<=1337)
        {
            room = "103";
        }
else if(roll>=1338&&roll<=1433)
        {
            room = "104";
        }
else if(roll>=1434&&roll<=1478)
        {
            room = "201";
        }
else if(roll>=1479&&roll<=1559)
        {
            room = "202";
        }
else if(roll>=1560&&roll<=1640)
        {
            room = "203";
        }
else if(roll>=1641&&roll<=1696)
        {
            room = "205";
        }
else if(roll>=1697&&roll<=1742)
        {
            room = "209";
        }
else if(roll>=1743&&roll<=1778)
        {
            room = "302";
        }
else if(roll>=1779&&roll<=1900)
        {
            room = "307";
        }
else if(roll>=1901&&roll<=1961)
        {
            room = "308";
        }
else if(roll>=1962&&roll<=1992)
        {
            room = "311";
        }
else if(roll>=1993&&roll<=2084)
        {
            room = "312";
        }
else if(roll>=2085&&roll<=2141)
        {
            room = "401(B)";
        }
else if(roll>=2142&&roll<=2212)
        {
            room = "407(B)";
        }
else if(roll>=2213&&roll<=2308)
        {
            room = "408";
        }
else if(roll>=2309&&roll<=2364)
        {
            room = "506";
        }
else if(roll>=2365&&roll<=2429)
        {
            room = "507";
        }
else if(roll>=2491&&roll<=2551)
        {
            room = "511";
        }
else if(roll>=2552&&roll<=2642)
        {
            room = "512";
        }


else if(roll>=2643&&roll<=2834)
        {
            room = "101, Hall Room";
        }
else if(roll>=2835&&roll<=3026)
        {
            room = "102, Hall Room";
        }
else if(roll>=3027&&roll<=3087)
        {
            room = "103";
        }
else if(roll>=3088&&roll<=3148)
        {
            room = "104";
        }
else if(roll>=3149&&roll<=3209)
        {
            room = "105";
        }
else if(roll>=3210&&roll<=3271)
        {
            room = "106";
        }
else if(roll>=3272&&roll<=3333)
        {
            room = "107";
        }
else if(roll>=3334&&roll<=3424)
        {
            room = "108";
        }
else if(roll>=3425&&roll<=3484)
        {
            room = "201";
        }
else if(roll>=3485&&roll<=3544)
        {
            room = "202";
        }
else if(roll>=3545&&roll<=3604)
        {
            room = "203";
        }
else if(roll>=3605&&roll<=3664)
        {
            room = "204";
        }
else if(roll>=3665&&roll<=3724)
        {
            room = "205";
        }
else if(roll>=3725&&roll<=3814)
        {
            room = "206";
        }
else if(roll>=3815&&roll<=3904)
        {
            room = "207";
        }
else if(roll>=3905&&roll<=3994)
        {
            room = "208";
        }
else if(roll>=3995&&roll<=4084)
        {
            room = "209";
        }
else if(roll>=4085&&roll<=4144)
        {
            room = "301";
        }
else if(roll>=4145&&roll<=4204)
        {
            room = "302";
        }

else if(roll>=4205&&roll<=4264)
        {
            room = "303";
        }
else if(roll>=4265&&roll<=4324)
        {
            room = "304";
        }
else if(roll>=4325&&roll<=4384)
        {
            room = "305";
        }
else if(roll>=4385&&roll<=4444)
        {
            room = "306";
        }
else if(roll>=4445&&roll<=4534)
        {
            room = "307";
        }
else if(roll>=4535&&roll<=4624)
        {
            room = "308";
        }
else if(roll>=4625&&roll<=4714)
        {
            room = "309";
        }
else if(roll>=4715&&roll<=4804)
        {
            room = "310";
        }
else if(roll>=4805&&roll<=4894)
        {
            room = "401";
        }
else if(roll>=4895&&roll<=4984)
        {
            room = "402";
        }
else if(roll>=4985&&roll<=5074)
        {
            room = "403";
        }
else if(roll>=5075&&roll<=5164)
        {
            room = "404";
        }
else if(roll>=5165&&roll<=5254)
        {
            room = "405";
        }
else if(roll>=5255&&roll<=5344)
        {
            room = "406";
        }
else if(roll>=5345&&roll<=5434)
        {
            room = "407";
        }
else if(roll>=5435&&roll<=5524)
        {
            room = "408";
        }
else if(roll>=5525&&roll<=5614)
        {
            room = "501";
        }
else if(roll>=5615&&roll<=5705)
        {
            room = "502";
        }
else if(roll>=5706&&roll<=5895)
        {
            room = "503,Hall Room";
        }

else if(roll>=5896&&roll<=5985)
        {
            room = "Computer Browsing Lab";
        }
else if(roll>=5986&&roll<=6100)
        {
            room = "Library Ground Open Space";
        }
else if(roll>=6101&&roll<=6245)
        {
            room = "Library 1st Floor Reading Room";
        }

else if(roll>=6246&&roll<=6820)
        {
            room = "Garage";
        }

else if(roll>=6821&&roll<=6912)
        {
            room = "101";
        }
else if(roll>=6913&&roll<=7004)
        {
            room = "102";
        }
else if(roll>=7005&&roll<=7096)
        {
            room = "103";
        }
else if(roll>=7097&&roll<=7168)
        {
            room = "104";
        }
else if(roll>=7169&&roll<=7238)
        {
            room = "105";
        }

else if(roll>=7239&&roll<=7318)
        {
            room = "106";
        }
else if(roll>=7319&&roll<=7378)
        {
            room = "107";
        }
else if(roll>=7379&&roll<=7468)
        {
            room = "108";
        }
else if(roll>=7469&&roll<=7558)
        {
            room = "109";
        }

else if(roll>=7559&&roll<=7763)
        {
            room = "Hall Room";
        }
else if(roll>=7764&&roll<=7855)
        {
            room = "101";
        }
else if(roll>=7856&&roll<=7947)
        {
            room = "102";
        }
else if(roll>=7948&&roll<=7987)
        {
            room = "103";
        }
else if(roll>=7988&&roll<=8027)
        {
            room = "104";
        }
else if(roll>=8028&&roll<=8067)
        {
            room = "105";
        }
else if(roll>=8068&&roll<=8107)
        {
            room = "106";
        }
else if(roll>=8108&&roll<=8147)
        {
            room = "107";
        }
else if(roll>=8148&&roll<=8187)
        {
            room = "108";
        }
else if(roll>=8188&&roll<=8227)
        {
            room = "109";
        }
else if(roll>=8228&&roll<=8267)
        {
            room = "110";
        }
else if(roll>=8268&&roll<=8307)
        {
            room = "111";
        }


else if(roll>=8308&&roll<=8364)
        {
            room = "104";
        }
else if(roll>=8365&&roll<=8440)
        {
            room = "112";
        }
else if(roll>=8441&&roll<=8502)
        {
            room = "115";
        }
else if(roll>=8505&&roll<=8590)
        {
            room = "205";
        }
else if(roll>=8591&&roll<=8734)
        {
            room = "206";
        }
else if(roll>=8738&&roll<=8812)
        {
            room = "207";
        }
else if(roll>=8813&&roll<=8912)
        {
            room = "2001";
        }
else if(roll>=8914&&roll<=8998)
        {
            room = "2002";
        }



        return room;
    }

    String findGBuilding(int roll){
        String building = "";
        if(roll>=1&&roll<=1119){
            building = "Administrative Building";
        }
        else if(roll>=1120&&roll<=2642){
            building = "Academic Building";
        }else if(roll>=2643&&roll<=5895){
            building = "Academic Building(New)";
        }
        else if(roll>=5896&&roll<=6245){
            building = "Library";
        }
        else if(roll>=6246&&roll<=6820){
            building = "University Garage";
        }else if(roll>=6821&&roll<=7238){
            building = "Bangabandhu University School and College (Tin Shed 1: Near Library)";
        }else if(roll>=7239&&roll<=7558){
            building = "Bangabandhu University School and College (Tin Shed 2: Near Library)";
        }
        else if(roll>=7559&&roll<=8307){
            building = "Bangabandhu University School and College (Near VC Residence)";
        }else if(roll>=8308&&roll<=8812){
            building = "Administrative Building";
        }else if(roll>=8813&&roll<=8998){
            building = "Diploma Building";
        }
        return building;
    }
}
