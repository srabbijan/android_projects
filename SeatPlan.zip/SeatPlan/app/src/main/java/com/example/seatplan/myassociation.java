package com.example.seatplan;

import android.content.DialogInterface;
import android.graphics.Color;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.LinkedHashMap;

public class myassociation extends AppCompatActivity {
    ExpandableListView expandableListView;
    LinkedHashMap<String,GroupInfo> subject = new LinkedHashMap<String,GroupInfo>();
    ArrayList<GroupInfo> dept = new ArrayList<GroupInfo>();
    CustomAdapter listAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myassociation);
        expandableListView =findViewById(R.id.expandView);
        listAdapter =new CustomAdapter(myassociation.this,dept);
        expandableListView.setAdapter(listAdapter);
        setTitle("Active Association");
        prepareListData();
        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView expandableListView, View view, int i, int i1, long l) {
                GroupInfo c = dept.get(i);
                ChildInfo h = c.getProductList().get(i1);
                String st = h.getName();

                if (i == 0) {
                    if(i1==0)
                    {
                        String district =getString(R.string.Dhaka);;
                        show(district,st);
                    }
                    else if(i1==1){
                        String district =getString(R.string.Gazipur);;
                        show(district,st);
                    } else if(i1==2){
                        String district =getString(R.string.Savar);;
                        show(district,st);
                    }else if(i1==3){
                        String district =getString(R.string.Manikganj);;
                        show(district,st);
                    }else if(i1==4){
                        String district =getString(R.string.Faridpur);;
                        show(district,st);
                    }
                    else if(i1==5){
                        String district =getString(R.string.Chatpur);;
                        show(district,st);
                    }else if(i1==6){
                        String district =getString(R.string.Tangail);;
                        show(district,st);
                    }else if(i1==7){
                        String district =getString(R.string.Gopalganj);;
                        show(district,st);
                    }else if(i1==8){
                        String district =getString(R.string.Narayanganj);;
                        show(district,st);
                    }else if(i1==9){
                        String district =getString(R.string.Rajbari);;
                        show(district,st);
                    }else if(i1==10){
                        String district =getString(R.string.Kishoreganj);;
                        show(district,st);
                    }else if(i1==11){
                        String district =getString(R.string.Shariatpur);;
                        show(district,st);
                    }else if(i1==12){
                        String district =getString(R.string.Madaripur);;
                        show(district,st);
                    }
                }
                else if (i == 1 ) {
                    if(i1==0){
                        String district =getString(R.string.Rajshahi);
                        show(district,st);
                    }
                    else if(i1==1){
                        String district =getString(R.string.Natore);
                        show(district,st);
                    }
                    else if(i1==2){
                        String district =getString(R.string.Pabna);
                        show(district,st);
                    }
                    else if(i1==3){
                        String district =getString(R.string.Naogaon);
                        show(district,st);
                    }
                    else if(i1==4){
                        String district =getString(R.string.Bogra);
                        show(district,st);
                    }
                    else if(i1==5){
                        String district =getString(R.string.Joypurhat);
                        show(district,st);
                    }
                    else if(i1==6) {
                        String district = getString(R.string.Sirajganj);
                        show(district, st);
                    }
                }
                else if (i == 2){
                    if(i1==0){
                        String district = getString(R.string.Khulna);
                        show(district, st);
                    }
                    else if(i1==1){
                        String district = getString(R.string.Jessore);
                        show(district, st);
                    }
                    else if(i1==2){
                        String district = getString(R.string.Magura);
                        show(district, st);
                    }
                    else if(i1==3){
                        String district = getString(R.string.Bagerhat);
                        show(district, st);
                    }
                    else if(i1==4){
                        String district = getString(R.string.Jhenaidah);
                        show(district, st);
                    }
                    else if(i1==5){
                        String district = getString(R.string.Meherpur);
                        show(district, st);
                    }
                    else if(i1==6){
                        String district = getString(R.string.Narail);
                        show(district, st);
                    }
                    else if(i1==7){
                        String district = getString(R.string.Satkhira);
                        show(district, st);
                    }
                    else if(i1==8){
                        String district = getString(R.string.Kushtia);
                        show(district, st);
                    }
                    else if(i1==9){
                        String district = getString(R.string.Chuadanga);
                        show(district, st);
                    }

                }
                else if(i==3){
                    if(i1==0){
                        String district = getString(R.string.Rangpur);
                        show(district, st);
                    }
                    else if(i1==1){
                        String district = getString(R.string.Thakurgaon);
                        show(district, st);
                    }
                    else if(i1==2){
                        String district = getString(R.string.Dinajpur);
                        show(district, st);
                    }
                    else if(i1==3){
                        String district = getString(R.string.Kurigram);
                        show(district, st);
                    }
                    else if(i1==4){
                        String district = getString(R.string.Lalmonirhat);
                        show(district, st);
                    }
                    else if(i1==5){
                        String district = getString(R.string.Gaibandha);
                        show(district, st);
                    }
                    else if(i1==6){
                        String district = getString(R.string.Nilphamari);
                        show(district, st);
                    }
                }
                else if (i==4){
                    if(i1==0){
                        String district = getString(R.string.Mymensingh);
                        show(district, st);
                    }
                    else if(i1==1){
                        String district = getString(R.string.Sherpur);
                        show(district, st);
                    }
                    else if(i1==2){
                        String district = getString(R.string.Jamalpur);
                        show(district, st);
                    }
                    else if(i1==3){
                        String district = getString(R.string.Netrokona);
                        show(district, st);
                    }
                }
                else if(i==5){
                    if(i1==0){
                        String district = getString(R.string.Sylhet);
                        show(district, st);
                    }
                    else if(i1==1){
                        String district = getString(R.string.Moulvibazar);
                        show(district, st);
                    }
                    else if(i1==2){
                        String district = getString(R.string.Sunamganj);
                        show(district, st);
                    }
                    else if(i1==3){
                        String district = getString(R.string.Habiganj);
                        show(district, st);
                    }
                }
                else if(i==6){
                    if(i1==0){
                        String district = getString(R.string.Chittagong);
                        show(district, st);
                    }
                    else if(i1==1){
                        String district = getString(R.string.Coxsbazar);
                        show(district, st);
                    }
                    else if(i1==2){
                        String district = getString(R.string.Noakhali);
                        show(district, st);
                    }
                    else if(i1==3){
                        String district = getString(R.string.Khagrachhari);
                        show(district, st);
                    }
                    else if(i1==4){
                        String district = getString(R.string.Lakshmipur);
                        show(district, st);
                    }
                    else if(i1==5){
                        String district = getString(R.string.Feni);
                        show(district, st);
                    }
                    else if(i1==6){
                        String district = getString(R.string.Comilla);
                        show(district, st);
                    }
                    else if(i1==7){
                        String district = getString(R.string.Brahmanbaria);
                        show(district, st);
                    }
                }
                else if(i==7)
                {
                    if(i1==0){
                        String district = getString(R.string.Barisal);
                        show(district, st);
                    }
                    else if(i1==1){
                        String district = getString(R.string.Pirojpur);
                        show(district, st);
                    }
                    else if(i1==2){
                        String district = getString(R.string.Patuakhali);
                        show(district, st);
                    }
                    else if(i1==3){
                        String district = getString(R.string.Jhalakathi);
                        show(district, st);
                    }
                    else if(i1==4){
                        String district = getString(R.string.Bhola);
                        show(district, st);
                    }
                    else if(i1==5){
                        String district = getString(R.string.Barguna);
                        show(district, st);
                    }
                }
                return false;
            }
        });
    }
    private void prepareListData(){

        addData("Dhaka","Dhaka");
        addData("Dhaka","Gazipur");
        addData("Dhaka","Savar");
        addData("Dhaka","Manikganj");
        addData("Dhaka","Faridpur");
        addData("Dhaka","Chatpur");
        addData("Dhaka","Tangail");
        addData("Dhaka","Gopalganj");
        addData("Dhaka","Narayanganj");
        addData("Dhaka","Rajbari");
        addData("Dhaka","Kishoreganj");
        addData("Dhaka","Shariatpur");
        addData("Dhaka","Madaripur");

        addData("Rajshahi","Rajshahi");
        addData("Rajshahi","Natore");
        addData("Rajshahi","Pabna");
        addData("Rajshahi","Naogaon");
        addData("Rajshahi","Bogra");
        addData("Rajshahi","Joypurhat");
        addData("Rajshahi","Sirajganj");

        addData("Khulna","Khulna");
        addData("Khulna","Jessore");
        addData("Khulna","Magura");
        addData("Khulna","Bagerhat");
        addData("Khulna","Jhenaidah");
        addData("Khulna","Meherpur");
        addData("Khulna","Narail");
        addData("Khulna","Satkhira");
        addData("Khulna","Kushtia");
        addData("Khulna","Chuadanga");

        addData("Rangpur","Rangpur");
        addData("Rangpur","Thakurgaon");
        addData("Rangpur","Dinajpur");
        addData("Rangpur","Kurigram");
        addData("Rangpur","Lalmonirhat");
        addData("Rangpur","Gaibandha");
        addData("Rangpur","Nilphamari");

        addData("Mymensingh","Mymensingh");
        addData("Mymensingh","Sherpur");
        addData("Mymensingh","Jamalpur");
        addData("Mymensingh","Netrokona");

        addData("Sylhet","Sylhet");
        addData("Sylhet","Moulvibazar");
        addData("Sylhet","Sunamganj");
        addData("Sylhet","Habiganj");

        addData("Chittagong","Chittagong");
        addData("Chittagong","Coxsbazar");
        addData("Chittagong","Noakhali");
        addData("Chittagong","Khagrachhari");
        addData("Chittagong","Lakshmipur");
        addData("Chittagong","Feni");
        addData("Chittagong","Comilla");
        addData("Chittagong","Brahmanbaria");


        addData("Barishal","Barishal");
        addData("Barishal","Pirojpur");
        addData("Barishal","Patuakhali");
        addData("Barishal","Jhalakathi");
        addData("Barishal","Bhola");
        addData("Barishal","Barguna");
    }
    void show(String district,String title){
        final TextView text=new TextView(myassociation.this);
        text.setText(district);
        text.setTextSize(23);
        text.setTextColor(Color.BLACK);
        text.setTextIsSelectable(true);
        final AlertDialog.Builder builder = new AlertDialog.Builder(myassociation.this);
        builder.setTitle(title);
        builder.setView(text);
        builder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        builder.show();
    }
    private int addData (String Topic, String SubTopic){
        int gppositon = 0;
        GroupInfo head = subject.get(Topic);
        if(head == null){
            head=new GroupInfo();
            head.setName(Topic);
            subject.put(Topic,head);
            dept.add(head);
        }
        ArrayList<ChildInfo> prolist = head.getProductList();
        int listsize =prolist.size();
        listsize++;
        ChildInfo detinfo = new ChildInfo();
        detinfo.setSequence(String.valueOf(listsize));
        detinfo.setName(SubTopic);
        prolist.add(detinfo);
        head.setProductList(prolist);
        gppositon = dept.indexOf(head);
        return gppositon;
    }
}
