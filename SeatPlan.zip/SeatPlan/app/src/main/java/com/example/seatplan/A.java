package com.example.seatplan;

import android.content.Context;
import android.widget.Toast;

public class A  {
    String findDInstitution(int roll){

        String institution = "";
        if(roll>=1&&roll<=8202){
            institution = "BSMRSTU";
        }
        else  if(roll>=8203&&roll<=10870){
            institution = "Govt. Bangabandhu College, Gopalganj";
        }
        else  if(roll>=10871&&roll<=12170){
            institution = "Sheikh Hasina Govt. Girls High School, Gopalganj";
        }else  if(roll>=12171&&roll<=13175){
            institution = "Binapani Govt. Girls High School, Gopalganj";
        }
        else  if(roll>=13176&&roll<=14291){
            institution = "Sheikh Fazilatun-nesa Govt. Mohila College,Gopalganj";
        }
    else  if(roll>=14292&&roll<=14756){
            institution = "Gopalganj Girls High School";
        }
else  if(roll>=14757&&roll<=15278){
            institution = "Technical School and College, Gopalganj";
        }
else  if(roll>=15279&&roll<=16116){
            institution = "Jugoshikha Girls School";
        }
else  if(roll>=16117&&roll<=17793){
            institution = "Hazi Lal Mia City College, Gopalganj";
        }
else  if(roll>=17794&&roll<=19024){
            institution = "S.M. Model Govt. High School";
        }
else  if(roll>=19025&&roll<=19986){
            institution = "Sarnakoli High School, Gopalganj";
        }



        return institution;
    }
    String findDRoom(int roll){
        String room = "";
        if(roll>=1&&roll<=165)
        {
            room = "Bank Varanda (Ground floor)";
        }
        else if(roll>=166&&roll<=330)
        {
            room = "Faculty Varanda (Ground floor)";
        }
        else if(roll>=331&&roll<=410)
        {
            room = "215";
        }
        else if(roll>=411&&roll<=490)
        {
            room = "303";
        }
        else if(roll>=491&&roll<=540)
        {
            room = "308";
        }
        else if(roll>=541&&roll<=620)
        {
            room = "403";
        }
        else if(roll>=621&&roll<=670)
                {
                    room = "408";
                }
else if(roll>=671&&roll<=740)
                {
                    room = "413";
                }
else if(roll>=741&&roll<=770)
                {
                    room = "414";
                }
else if(roll>=771&&roll<=820)
                {
                    room = "416";
                }
else if(roll>=821&&roll<=890)
                {
                    room = "503";
                }
else if(roll>=891&&roll<=935)
                {
                    room = "504";
                }
else if(roll>=936&&roll<=975)
                {
                    room = "506";
                }
else if(roll>=976&&roll<=1055)
                {
                    room = "513";
                }
else if(roll>=1056&&roll<=1100)
                {
                    room = "516";
                }

                //Academic Building
else if(roll>=1101&&roll<=1230)
                {
                    room = "Varanda (Ground floor), infront of Pharmacy Lab";
                }
else if(roll>=1231&&roll<=1315)
                {
                    room = "103";
                }
else if(roll>=1316&&roll<=1410)
                {
                    room = "104";
                }
else if(roll>=1411&&roll<=1455)
                {
                    room = "201";
                }
else if(roll>=1456&&roll<=1535)
                {
                    room = "202";
                }
else if(roll>=1536&&roll<=1615)
                {
                    room = "203";
                }
else if(roll>=1616&&roll<=1670)
                {
                    room = "205";
                }
else if(roll>=1671&&roll<=1715)
                {
                    room = "209";
                }
else if(roll>=1716&&roll<=1750)
                {
                    room = "302";
                }
else if(roll>=1751&&roll<=1870)
                {
                    room = "307";
                }
                else if(roll>=1871&&roll<=1930)
                {
                    room = "308";
                }
else if(roll>=1931&&roll<=1960)
                {
                    room = "311";
                }
else if(roll>=1961&&roll<=2050)
                {
                    room = "312";
                }
else if(roll>=2051&&roll<=2105)
                {
                    room = "401(B)";
                }
else if(roll>=2106&&roll<=2175)
                {
                    room = "407(B)";
                }
else if(roll>=2176&&roll<=2270)
                {
                    room = "408";
                }
else if(roll>=2271&&roll<=2325)
                {
                    room = "506";
                }
else if(roll>=2326&&roll<=2390)
                {
                    room = "507";
                }
else if(roll>=2391&&roll<=2450)
                {
                    room = "508";
                }
else if(roll>=2451&&roll<=2510)
                {
                    room = "511";
                }
else if(roll>=2511&&roll<=2600)
                {
                    room = "512";
                }
//Academic Building (New)

else if(roll>=2601&&roll<=2790)
                {
                    room = "101, Hall Room";
                }
else if(roll>=2791&&roll<=2980)
                {
                    room = "102, Hall Room";
                }
else if(roll>=2981&&roll<=3040)
                {
                    room = "103";
                }
else if(roll>=3041&&roll<=3100)
                {
                    room = "104";
                }
else if(roll>=3101&&roll<=3160)
                {
                    room = "105";
                }
else if(roll>=3161&&roll<=3220)
                {
                    room = "106";
                }
else if(roll>=3221&&roll<=3280)
                {
                    room = "107";
                }

      else if(roll>=3281&&roll<=3370)
                {
                    room = "108";
                }
else if(roll>=3371&&roll<=3430)
                {
                    room = "201";
                }
else if(roll>=3431&&roll<=3490)
                {
                    room = "202";
                }
else if(roll>=3491&&roll<=3550)
                {
                    room = "203";
                }
else if(roll>=3551&&roll<=3610)
                {
                    room = "204";
                }
else if(roll>=3611&&roll<=3670)
                {
                    room = "205";
                }
else if(roll>=3671&&roll<=3760)
                {
                    room = "206";
                }
else if(roll>=3761&&roll<=3850)
                {
                    room = "207";
                }
else if(roll>=3851&&roll<=3940)
                {
                    room = "208";
                }
else if(roll>=3941&&roll<=4030)
                {
                    room = "209";
                }
else if(roll>=4031&&roll<=4090)
                {
                    room = "301";
                }
else if(roll>=4091&&roll<=4150)
                {
                    room = "302";
                }
else if(roll>=4151&&roll<=4210)
                {
                    room = "303";
                }
else if(roll>=4211&&roll<=4270)
                {
                    room = "304";
                }
else if(roll>=4271&&roll<=4331)
                {
                    room = "305";
                }
else if(roll>=4332&&roll<=4392)
                {
                    room = "306";
                }
else if(roll>=4393&&roll<=4482)
                {
                    room = "307";
                }
else if(roll>=4483&&roll<=4572)
                {
                    room = "308";
                }
else if(roll>=4573&&roll<=4662)
                {
                    room = "309";
                }
else if(roll>=4663&&roll<=4752)
                {
                    room = "310";
                }
                else if(roll>=4753&&roll<=4842)
                {
                    room = "401";
                }
else if(roll>=4843&&roll<=4932)
                {
                    room = "402";
                }
                else if(roll>=4933&&roll<=5022)
                {
                    room = "403";
                }

else if(roll>=5023&&roll<=5112)
                {
                    room = "404";
                }
else if(roll>=5113&&roll<=5202)
                {
                    room = "405";
                }
else if(roll>=5203&&roll<=5292)
                {
                    room = "406";
                }
else if(roll>=5293&&roll<=5382)
                {
                    room = "407";
                }
else if(roll>=5383&&roll<=5472)
                {
                    room = "408";
                }
else if(roll>=5473&&roll<=5562)
                {
                    room = "501";
                }
else if(roll>=5563&&roll<=5652)
                {
                    room = "502";
                }
else if(roll>=5653&&roll<=5842)
                {
                    room = "503,Hall Room";
                }

        //Library
else if(roll>=5843&&roll<=5932)
                {
                    room = "Computer Browsing Lab";
                }
else if(roll>=5933&&roll<=6042)
                {
                    room = "Library Ground Open Space";
                }
else if(roll>=6043&&roll<=6182)
                {
                    room = "Library 1st Floor Reading Room";
                }

                //University Garage
else if(roll>=6183&&roll<=6732)
                {
                    room = "Garage";
                }
                //Tin Shed 1
else if(roll>=6733&&roll<=6822)
                {
                    room = "101";
                }
else if(roll>=6823&&roll<=6912)
                {
                    room = "102";
                }
else if(roll>=6913&&roll<=7002)
                {
                    room = "103";
                }
else if(roll>=7003&&roll<=7072)
                {
                    room = "104";
                }
else if(roll>=7073&&roll<=7142)
                {
                    room = "105";
                }

                //Tin Shed 2
else if(roll>=7143&&roll<=7222)
                {
                    room = "106";
                }
else if(roll>=7223&&roll<=7282)
                {
                    room = "107";
                }
else if(roll>=7283&&roll<=7372)
                {
                    room = "108";
                }
else if(roll>=7373&&roll<=7462)
                {
                    room = "109";
                }

                //VC
else if(roll>=7463&&roll<=7662)
                {
                    room = "Hall Room";
                }
else if(roll>=7663&&roll<=7752)
                {
                    room = "101";
                }
else if(roll>=7753&&roll<=7842)
                {
                    room = "102";
                }
else if(roll>=7843&&roll<=7882)
                {
                    room = "103";
                }
else if(roll>=7883&&roll<=7922)
                {
                    room = "104";
                }
else if(roll>=7923&&roll<=7962)
                {
                    room = "105";
                }
else if(roll>=7963&&roll<=8002)
                {
                    room = "106";
                }
else if(roll>=8003&&roll<=8042)
                {
                    room = "107";
                }
else if(roll>=8043&&roll<=8082)
                {
                    room = "108";
                }
else if(roll>=8083&&roll<=8122)
                {
                    room = "109";
                }
else if(roll>=8123&&roll<=8162)
                {
                    room = "110";
                }
else if(roll>=8163&&roll<=8202)
                {
                    room = "111";
                }

                //Govt. Bangabandhu College, Gopalganj
else if(roll>=8203&&roll<=8373)
                {
                    room = "1001";
                }
else if(roll>=8374&&roll<=8544)
                {
                    room = "1002";
                }
else if(roll>=8545&&roll<=8644)
                {
                    room = "2001";
                }
else if(roll>=8645&&roll<=8744)
                {
                    room = "2002";
                }
else if(roll>=8745&&roll<=8839)
                {
                    room = "2003";
                }
else if(roll>=8840&&roll<=8929)
                {
                    room = "2004";
                }
else if(roll>=8930&&roll<=9019)
                {
                    room = "3001";
                }
else if(roll>=9020&&roll<=9094)
                {
                    room = "3004";
                }
else if(roll>=9095&&roll<=9156)
                {
                    room = "4001";
                }
else if(roll>=9157&&roll<=9206)
                {
                    room = "4004";
                }
else if(roll>=9207&&roll<=9377)
                {
                    room = "5001";
                }
else if(roll>=9378&&roll<=9467)
                {
                    room = "102";
                }
else if(roll>=9468&&roll<=9529)
                {
                    room = "104";
                }
else if(roll>=9530&&roll<=9619)
                {
                    room = "105";
                }
else if(roll>=9620&&roll<=9709)
                {
                    room = "106";
                }
else if(roll>=9710&&roll<=9804)
                {
                    room = "202";
                }
else if(roll>=9805&&roll<=9869)
                {
                    room = "203";
                }
else if(roll>=9870&&roll<=9960)
                {
                    room = "205";
                }
else if(roll>=9961&&roll<=10050)
                {
                    room = "206";
                }
else if(roll>=10051&&roll<=10120)
                {
                    room = "302";
                }
else if(roll>=10121&&roll<=10210)
                {
                    room = "303";
                }
else if(roll>=10211&&roll<=10300)
                {
                    room = "305";
                }
else if(roll>=10301&&roll<=10395)
                {
                    room = "306";
                }
else if(roll>=10396&&roll<=10455)
                {
                    room = "402";
                }
else if(roll>=10456&&roll<=10590)
                {
                    room = "403";
                }
else if(roll>=10591&&roll<=10685)
                {
                    room = "405";
                }
else if(roll>=10686&&roll<=10780)
                {
                    room = "406";
                }
else if(roll>=10781&&roll<=10870)
                {
                    room = "Girl's Common Room";
                }
//Sheikh Hasina Govt. Girls High School, Gopalganj
        else if(roll>=10871&&roll<=10935)
        {
            room = "101";
        }

        else if(roll>=10936&&roll<=11000)
        {
            room = "102";
        }
else if(roll>=11001&&roll<=11065)
        {
            room = "103";
        }
else if(roll>=11066&&roll<=11195)
        {
            room = "104";
        }
else if(roll>=11196&&roll<=11260)
        {
            room = "201";
        }
else if(roll>=11261&&roll<=11325)
        {
            room = "202";
        }
else if(roll>=11326&&roll<=11390)
        {
            room = "203";
        }
else if(roll>=11391&&roll<=11455)
        {
            room = "204";
        }
else if(roll>=11456&&roll<=11520)
        {
            room = "205";
        }
else if(roll>=11521&&roll<=11585)
        {
            room = "206";
        }
else if(roll>=11586&&roll<=11650)
        {
            room = "301";
        }
else if(roll>=11651&&roll<=11715)
        {
            room = "302";
        }
else if(roll>=11716&&roll<=11780)
        {
            room = "303";
        }
else if(roll>=11781&&roll<=11845)
        {
            room = "304";
        }
else if(roll>=11846&&roll<=11910)
        {
            room = "305";
        }
else if(roll>=11911&&roll<=11975)
        {
            room = "306";
        }
else if(roll>=11976&&roll<=12040)
        {
            room = "401";
        }
else if(roll>=12041&&roll<=12105)
        {
            room = "403";
        }
else if(roll>=12106&&roll<=12170)
        {
            room = "404";
        }
        //Binapani Govt. Girls High School, Gopalganj
        else if(roll>=12171&&roll<=12251)
        {
            room = "107";
        }
else if(roll>=12252&&roll<=12316)
        {
            room = "108";
        }
else if(roll>=12317&&roll<=12397)
        {
            room = "109";
        }
else if(roll>=12398&&roll<=12452)
        {
            room = "110";
        }
else if(roll>=12453&&roll<=12502)
        {
            room = "111";
        }
else if(roll>=12503&&roll<=12598)
        {
            room = "112";
        }
else if(roll>=12599&&roll<=12646)
        {
            room = "113";
        }
else if(roll>=12647&&roll<=12711)
        {
            room = "201";
        }
else if(roll>=12712&&roll<=12776)
        {
            room = "202";
        }
else if(roll>=12777&&roll<=12841)
        {
            room = "203";
        }
else if(roll>=12842&&roll<=12891)
        {
            room = "204";
        }
else if(roll>=12892&&roll<=12929)
        {
            room = "205";
        }
else if(roll>=12930&&roll<=12976)
        {
            room = "206";
        }
else if(roll>=12977&&roll<=13038)
        {
            room = "208";
        }
else if(roll>=13039&&roll<=13119)
        {
            room = "209";
        }
else if(roll>=13120&&roll<=13175)
        {
            room = "210";
        }
//Sheikh Fazilatun-nesa Govt. Mohila College, Gopalganj
        else if(roll>=13176&&roll<=13290)
        {
            room = "112";
        }
else if(roll>=13291&&roll<=13350)
        {
            room = "201";
        }
else if(roll>=13351&&roll<=13410)
        {
            room = "301";
        }
else if(roll>=13411&&roll<=13495)
        {
            room = "304";
        }
else if(roll>=13496&&roll<=13580)
        {
            room = "401";
        }
else if(roll>=13581&&roll<=13665)
        {
            room = "404";
        }
else if(roll>=13666&&roll<=13723)
        {
            room = "105";
        }
else if(roll>=13724&&roll<=13781)
        {
            room = "106";
        }
else if(roll>=13782&&roll<=13841)
        {
            room = "107";
        }
else if(roll>=13842&&roll<=13901)
        {
            room = "108";
        }
else if(roll>=13902&&roll<=13941)
        {
            room = "501";
        }
else if(roll>=13942&&roll<=13981)
        {
            room = "502";
        }
else if(roll>=13982&&roll<=14021)
        {
            room = "601";
        }
else if(roll>=14022&&roll<=14061)
        {
            room = "602";
        }
else if(roll>=14062&&roll<=14156)
        {
            room = "701";
        }
else if(roll>=14157&&roll<=14251)
        {
            room = "801";
        }
else if(roll>=14252&&roll<=14291)
        {
            room = "802";
        }
//Gopalganj Girls High School

else if(roll>=14292&&roll<=14359)
        {
            room = "101";
        }
else if(roll>=14360&&roll<=14404)
        {
            room = "102";
        }
else if(roll>=14405&&roll<=14472)
        {
            room = "103";
        }
else if(roll>=14473&&roll<=14540)
        {
            room = "104";
        }
else if(roll>=14541&&roll<=14615)
        {
            room = "105";
        }
else if(roll>=14616&&roll<=14650)
        {
            room = "106";
        }
else if(roll>=14651&&roll<=14685)
        {
            room = "107";
        }
else if(roll>=14686&&roll<=14720)
        {
            room = "208";
        }
else if(roll>=14722&&roll<=14756)
        {
            room = "209";
        }
//Technical School and College, Gopalganj

else if(roll>=14757&&roll<=14813)
        {
            room = "104";
        }
else if(roll>=14814&&roll<=14888)
        {
            room = "112";
        }
else if(roll>=14889&&roll<=14950)
        {
            room = "115";
        }
else if(roll>=14951&&roll<=15007)
        {
            room = "205";
        }
else if(roll>=15008&&roll<=15112)
        {
            room = "206";
        }
else if(roll>=15113&&roll<=15154)
        {
            room = "207";
        }
else if(roll>=15155&&roll<=15216)
        {
            room = "2001";
        }
        else if(roll>=15217&&roll<=15278)
        {
            room = "2002";
        }

        //Jugoshikha Girls School
 else if(roll>=15279&&roll<=15340)
        {
            room = "01";
        }
 else if(roll>=15341&&roll<=15402)
        {
            room = "02";
        }
 else if(roll>=15403&&roll<=15464)
        {
            room = "03";
        }
else if(roll>=15465&&roll<=15526)
        {
            room = "04";
        }
else if(roll>=15527&&roll<=15589)
        {
            room = "05";
        }
else if(roll>=15590&&roll<=15651)
        {
            room = "06";
        }
else if(roll>=15652&&roll<=15713)
        {
            room = "07";
        }
else if(roll>=15714&&roll<=15760)
        {
            room = "08";
        }
else if(roll>=15761&&roll<=15890)
        {
            room = "09";
        }
else if(roll>=15891&&roll<=16041)
        {
            room = "10";
        }
else if(roll>=16042&&roll<=16116)
        {
            room = "11";
        }

        //Hazi Lal Mia City College, Gopalganj
else if(roll>=16117&&roll<=16201)
        {
            room = "06";
        }
else if(roll>=16202&&roll<=16286)
        {
            room = "07";
        }
else if(roll>=16287&&roll<=16411)
        {
            room = "08";
        }
else if(roll>=16412&&roll<=16473)
        {
            room = "09";
        }
else if(roll>=16474&&roll<=16598)
        {
            room = "10";
        }
else if(roll>=16599&&roll<=16660)
        {
            room = "20";
        }
else if(roll>=16661&&roll<=16722)
        {
            room = "21";
        }
else if(roll>=16723&&roll<=16784)
        {
            room = "204";
        }
else if(roll>=16785&&roll<=16924)
        {
            room = "205";
        }
else if(roll>=16925&&roll<=16986)
        {
            room = "304";
        }
else if(roll>=16987&&roll<=17048)
        {
            room = "305";
        }
else if(roll>=17049&&roll<=17133)
        {
            room = "ICT Room";
        }
else if(roll>=17134&&roll<=17283)
        {
            room = "16";
        }
else if(roll>=17284&&roll<=17443)
        {
            room = "17";
        }
else if(roll>=17444&&roll<=17523)
        {
            room = "18";
        }
else if(roll>=17524&&roll<=17603)
        {
            room = "19";
        }
else if(roll>=17604&&roll<=17793)
        {
            room = "Hall Room";
        }
//S.M. Model Govt. High School
else if(roll>=17794&&roll<=17873)
        {
            room = "01";
        }
else if(roll>=17874&&roll<=17953)
        {
            room = "02";
        }
else if(roll>=17954&&roll<=18033)
        {
            room = "03";
        }
else if(roll>=18034&&roll<=18095)
        {
            room = "04";
        }
else if(roll>=18096&&roll<=18190)
        {
            room = "05";
        }
else if(roll>=18191&&roll<=18237)
        {
            room = "06";
        }
else if(roll>=18238&&roll<=18332)
        {
            room = "07";
        }
else if(roll>=18333&&roll<=18394)
        {
            room = "08";
        }
else if(roll>=18395&&roll<=18489)
        {
            room = "09";
        }
else if(roll>=18490&&roll<=18551)
        {
            room = "10";
        }
else if(roll>=18552&&roll<=18631)
        {
            room = "11";
        }
else if(roll>=18632&&roll<=18776)
        {
            room = "12";
        }
else if(roll>=18777&&roll<=18838)
        {
            room = "13";
        }
else if(roll>=18839&&roll<=18900)
        {
            room = "14";
        }
else if(roll>=18901&&roll<=18962)
        {
            room = "15";
        }
else if(roll>=18963&&roll<=19024)
        {
            room = "16";
        }
//Sarnakoli High School, Gopalganj

        else if(roll>=19025&&roll<=19064)
        {
            room = "01";
        }
        else if(roll>=19065&&roll<=19104)
        {
            room = "02";
        }
         else if(roll>=19105&&roll<=19139)
        {
            room = "105";
        }
else if(roll>=19140&&roll<=19174)
        {
            room = "106";
        }
else if(roll>=19175&&roll<=19212)
        {
            room = "201";
        }
else if(roll>=19213&&roll<=19250)
        {
            room = "202";
        }
else if(roll>=19251&&roll<=19288)
        {
            room = "203";
        }
else if(roll>=19289&&roll<=19326)
        {
            room = "301";
        }
else if(roll>=19327&&roll<=19364)
        {
            room = "302";
        }
else if(roll>=19365&&roll<=19429)
        {
            room = "303";
        }
else if(roll>=19430&&roll<=19467)
        {
            room = "304";
        }
else if(roll>=19468&&roll<=19523)
        {
            room = "305";
        }
else if(roll>=19525&&roll<=19986)
        {
            room = "Hall Room";
        }

        return room;
    }
    String findDBuilding(int roll){
        String building = "";
        if(roll>=1&&roll<=1100){
            building = "Administrative Building";
        }
else if(roll>=1101&&roll<=2600){
            building = "Academic Building";
        }
else if(roll>=2601&&roll<=5842){
            building = "Academic Building (New)";
        }
else if(roll>=5843&&roll<=6182){
            building = "Library";
        }
else if(roll>=6183&&roll<=6732){
            building = "University Garage";
        }
else if(roll>=6733&&roll<=7142){
            building = "Banganadhu School and College(Tin Shed 1: Near Library)";
        }
else if(roll>=7143&&roll<=7462){
            building = "Banganadhu School and College(Tin Shed 2: Near Library)";
        }
else if(roll>=7463&&roll<=8202){
            building = "Banganadhu School and College(Near VC Residence)";
        }

else if(roll>=13176&&roll<=13665){
            building = "Science Building";
        }
else if(roll>=13666&&roll<=13901){
            building = "Arts Building";
        }
else if(roll>=13902&&roll<=14291){
            building = "Honours Building";
        }
else if(roll>=14757&&roll<=15154){
            building = "Administrative Building";
        }
else if(roll>=15155&&roll<=15278){
            building = "Diploma Building";
        }
else if(roll>=16117&&roll<=16598){
            building = "Luthfor Rahman Bhabon";
        }
else if(roll>=16599&&roll<=16722){
            building = "Elias Rahman Bhabon";
        }
else if(roll>=16723&&roll<=17133){
            building = "Sobura Rahman Bhabon";
        }
else if(roll>=17134&&roll<=17603){
            building = "Banijya Bhaban";
        }
else if(roll>=19025&&roll<=19104){
            building = "Tin Shed Building";
        }
else if(roll>=19105&&roll<=19523){
            building = "Academic Building-1";
        }
        return building;
    }


}
