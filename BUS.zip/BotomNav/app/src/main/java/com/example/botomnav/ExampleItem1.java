package com.example.botomnav;

public class ExampleItem1 {

    private String mText1;


    public ExampleItem1(String text1) {
        mText1 = text1;

    }
    public String getText1() {
        return mText1;
    }


}
