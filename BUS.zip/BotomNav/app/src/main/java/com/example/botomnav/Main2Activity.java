package com.example.botomnav;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.ListView;

import java.util.ArrayList;

public class Main2Activity extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        setTitle("BSMRSTU BUS");
        add1();
        add2();

    }
    public void add1(){
        ArrayList<ExampleItem1> exampleList = new ArrayList<>();
        exampleList.add(new ExampleItem1("7:00 AM বিশ্ববিদ্যালয়-শহর-কাশিয়ানী-পোনা" ));
        exampleList.add(new ExampleItem1( "7:00 AM বিশ্ববিদ্যালয়-শহর-সাতপাড়"));
        exampleList.add(new ExampleItem1( "7:15 AM বিশ্ববিদ্যালয়-বিশ্বরোড-পুলিশলাইন"));
        exampleList.add(new ExampleItem1( "7:15 AM বিশ্ববিদ্যালয়-বিশ্বরোড-কোটালিপাড়া"));
        exampleList.add(new ExampleItem1( "8:15 AM বিশ্ববিদ্যালয়-বিশ্বরোড-পুলিশলাইন"));
        exampleList.add(new ExampleItem1( "8:15 AM বিশ্ববিদ্যালয়-বিশ্বরোড-পুলিশলাইন [এসি]"));
        exampleList.add(new ExampleItem1( "8:20 AM বিশ্ববিদ্যালয়-লঞ্চঘাট"));
        exampleList.add(new ExampleItem1( "9:45 AM বিশ্ববিদ্যালয়-কুশলী"));
        exampleList.add(new ExampleItem1( "1:05 PM বিশ্ববিদ্যালয়-শহর-পুলিশলাইন [এসি]"));
        exampleList.add(new ExampleItem1( "1:10 PM বিশ্ববিদ্যালয়-শহর-পুলিশলাইন"));
        exampleList.add(new ExampleItem1( "1:10 PM বিশ্ববিদ্যালয়-লঞ্চঘাট"));
        exampleList.add(new ExampleItem1( "2:10 PM বিশ্ববিদ্যালয়-শহর-পুলিশলাইন"));
        exampleList.add(new ExampleItem1( "5:10 PM বিশ্ববিদ্যালয়-শহর-কাশিয়ানী"));
        exampleList.add(new ExampleItem1( "5:10 AM বিশ্ববিদ্যালয়-শহর-পুলিশলাইন-সাতপাড়"));
        exampleList.add(new ExampleItem1( "5:10 AM বিশ্ববিদ্যালয়-বেদগ্রাম-কোটালিপাড়া"));
        exampleList.add(new ExampleItem1( "5:10 PM বিশ্ববিদ্যালয়-ঘোনাপাড়া-টুঙ্গিপাড়া"));
        exampleList.add(new ExampleItem1( "5:10 PM বিশ্ববিদ্যালয়-শহর-পুলিশলাইন [এসি]"));
        exampleList.add(new ExampleItem1( "5:10 PM বিশ্ববিদ্যালয়-শহর-পুলিশলাইন"));
        exampleList.add(new ExampleItem1(  "5:10 PM বিশ্ববিদ্যালয়-লঞ্চঘাট"));
        exampleList.add(new ExampleItem1(  "5:10 PM বিশ্ববিদ্যালয়-সোনাডাঙ্গা,খুলনা"));
        exampleList.add(new ExampleItem1(  "8:10 PM বিশ্ববিদ্যালয়-লঞ্চঘাট"));
        mRecyclerView = findViewById(R.id.recyclerView1);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mAdapter = new ExampleAdapter1(exampleList);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);

    }
    public void add2(){
        ArrayList<ExampleItem1> exampleList = new ArrayList<>();
        exampleList.add(new ExampleItem1( "7:40 AM পুলিশলাইন-শহর-বিশ্ববিদ্যালয়-টুঙ্গিপাড়া"));
        exampleList.add(new ExampleItem1( "7:50 AM পোনা-কাশিয়ানী-শহর-বিশ্ববিদ্যালয়"));
        exampleList.add(new ExampleItem1( "8:00 AM কোটালিপাড়া-বিশ্বরোড-বিশ্ববিদ্যালয়"));
        exampleList.add(new ExampleItem1( "8:30 AM টুঙ্গিপাড়া-ঘোনাপাড়া-বিশ্ববিদ্যালয়"));
        exampleList.add(new ExampleItem1( "8:30 AM পুলিশলাইন-শহর-বিশ্ববিদ্যালয়"));
        exampleList.add(new ExampleItem1( "8:35 AM পুলিশলাইন-শহর-বিশ্ববিদ্যালয় [এসি]"));
        exampleList.add(new ExampleItem1( "8:35 AM লঞ্চঘাট-বিশ্ববিদ্যালয়"));
        exampleList.add(new ExampleItem1( "8:40 AM পাচুড়িয়া-বিশ্ববিদ্যালয়"));
        exampleList.add(new ExampleItem1( "9:15 AM পুলিশলাইন-শহর-বিশ্ববিদ্যালয়"));
        exampleList.add(new ExampleItem1( "9:20 AM লঞ্চঘাট-বিশ্ববিদ্যালয়"));
        exampleList.add(new ExampleItem1( "9:25 AM পাচুড়িয়া-বিশ্ববিদ্যালয়"));
        exampleList.add(new ExampleItem1( "12:45 PM কুশলী-বিশ্ববিদ্যালয়"));
        exampleList.add(new ExampleItem1( "1:30 PM পুলিশলাইন-বিশ্বরোড-বিশ্ববিদ্যালয়"));
        exampleList.add(new ExampleItem1( "1:40 PM লঞ্চঘাট-বিশ্ববিদ্যালয়"));
        exampleList.add(new ExampleItem1( "1:45 PM পুলিশলাইন-বিশ্বরোড-বিশ্ববিদ্যালয় [এসি]"));
        exampleList.add(new ExampleItem1( "2:40 PM পুলিশলাইন-বিশ্বরোড-বিশ্ববিদ্যালয়"));
        exampleList.add(new ExampleItem1( "5:30 PM পুলিশলাইন-বিশ্বরোড-বিশ্ববিদ্যালয় [এসি]"));
        exampleList.add(new ExampleItem1( "5:30 PM পুলিশলাইন-বিশ্বরোড-বিশ্ববিদ্যালয়"));
        exampleList.add(new ExampleItem1( "5:30 PM লঞ্চঘাট-বিশ্ববিদ্যালয়"));
        exampleList.add(new ExampleItem1( "5:40 PM টুঙ্গিপাড়া-ঘোনাপাড়া-বিশ্ববিদ্যালয়"));
        exampleList.add(new ExampleItem1( "6:00 PM কোটালিপাড়া-বেদগ্রাম-বিশ্ববিদ্যালয়"));
        exampleList.add(new ExampleItem1( "8:30 PM লঞ্চঘাট-বিশ্ববিদ্যালয়"));
        mRecyclerView = findViewById(R.id.recyclerView2);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mAdapter = new ExampleAdapter1(exampleList);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);

    }

}
