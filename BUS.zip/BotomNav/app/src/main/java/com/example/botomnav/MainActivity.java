package com.example.botomnav;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    private RecyclerView mRecyclerView,m;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    return true;
                case R.id.navigation_dashboard:
                {
                    Intent intent = new Intent(MainActivity.this,Main2Activity.class);
                    startActivity(intent);
                    return true;
                }
                case R.id.navigation_notifications:
                {
                    Intent intent = new Intent(MainActivity.this,Developer.class);
                    startActivity(intent);
                    return true;
                }
            }
            return false;
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("BSMRSTU BUS");
        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        start();
    }
    public void start(){
    Calendar now = Calendar.getInstance();
    int hour = now.get(Calendar.HOUR_OF_DAY);
    int minute = now.get(Calendar.MINUTE);
    int day = now.get(Calendar.DAY_OF_WEEK);
    int ck = hour*100+minute;

    if(day==7||day==6)
    {
        if(day==6){
            frisat1(" It's Friday. ", " No Bus  ");
            frisat2(" It's Friday. ", " No Bus  ");
        }
        else {

            frisat1 ( " It's Saturday. ", " No Bus  ");
            frisat2 ( " It's Saturday. ", " No Bus  ");
        }
    }
    else
    {
        compareDates(ck);
        compareDates1(ck);
    }
}
    public void frisat1(String f,String s){
    ArrayList<ExampleItem> exampleList = new ArrayList<>();
    exampleList.add(new ExampleItem( f,s));
    mRecyclerView = findViewById(R.id.recyclerView1);
    mRecyclerView.setHasFixedSize(true);
    mLayoutManager = new LinearLayoutManager(this);
    mAdapter = new ExampleAdapter(exampleList);
    mRecyclerView.setLayoutManager(mLayoutManager);
    mRecyclerView.setAdapter(mAdapter);
}
    public void frisat2(String f,String s){
    ArrayList<ExampleItem> exampleList = new ArrayList<>();
    exampleList.add(new ExampleItem( f,s));
    mRecyclerView = findViewById(R.id.recyclerView2);
    mRecyclerView.setHasFixedSize(true);
    mLayoutManager = new LinearLayoutManager(this);
    mAdapter = new ExampleAdapter(exampleList);
    mRecyclerView.setLayoutManager(mLayoutManager);
    mRecyclerView.setAdapter(mAdapter);
}
    public void compareDates(int ck){

        mRecyclerView = findViewById(R.id.recyclerView1);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
            if ( 7*100+0>=ck && 0<=ck) {
                ArrayList<ExampleItem> exampleList = new ArrayList<>();
                String string = timeRem("07:00");
                String string1 = timeRem("07:15");
                exampleList.add(new ExampleItem( "7:00 AM বিশ্ববিদ্যালয়-শহর-কাশিয়ানী-পোনা", string));
                exampleList.add(new ExampleItem( "7:00 AM বিশ্ববিদ্যালয়-শহর-সাতপাড়", string));
                exampleList.add(new ExampleItem( "7:15 AM বিশ্ববিদ্যালয়-বিশ্বরোড-পুলিশলাইন", string1));
                exampleList.add(new ExampleItem( "7:15 AM বিশ্ববিদ্যালয়-বিশ্বরোড-কোটালিপাড়া", string1));
                mAdapter = new ExampleAdapter(exampleList);
                mRecyclerView.setLayoutManager(mLayoutManager);
                mRecyclerView.setAdapter(mAdapter);
            }
            else if (7*100+15>=ck && 7*100+0<ck){
                ArrayList<ExampleItem> exampleList = new ArrayList<>();
                String string = timeRem("07:15");
                exampleList.add(new ExampleItem( "7:15 AM বিশ্ববিদ্যালয়-বিশ্বরোড-পুলিশলাইন", string));
                exampleList.add(new ExampleItem( "7:15 AM বিশ্ববিদ্যালয়-বিশ্বরোড-কোটালিপাড়া", string));
                mAdapter = new ExampleAdapter(exampleList);
                mRecyclerView.setLayoutManager(mLayoutManager);
                mRecyclerView.setAdapter(mAdapter);
            }
            else if (8*100+15>=ck && 7*100+15<ck){
                ArrayList<ExampleItem> exampleList = new ArrayList<>();
                String string = timeRem("08:15");
                String string1 = timeRem("08:20");
                exampleList.add(new ExampleItem(  "8:15 AM বিশ্ববিদ্যালয়-বিশ্বরোড-পুলিশলাইন [এসি]", string));
                exampleList.add(new ExampleItem( "8:15 AM বিশ্ববিদ্যালয়-বিশ্বরোড-পুলিশলাইন", string));
                exampleList.add(new ExampleItem( "8:20 AM বিশ্ববিদ্যালয়-লঞ্চঘাট", string1));
                exampleList.add(new ExampleItem( "8:20 AM বিশ্ববিদ্যালয়-পাচুড়িয়া", string1));
                mAdapter = new ExampleAdapter(exampleList);
                mRecyclerView.setLayoutManager(mLayoutManager);
                mRecyclerView.setAdapter(mAdapter);
            }
            else if (8*100+20>=ck && 8*100+15<ck){
                ArrayList<ExampleItem> exampleList = new ArrayList<>();
                String string = timeRem("08:20");
                exampleList.add(new ExampleItem( "8:20 AM বিশ্ববিদ্যালয়-লঞ্চঘাট", string));
                exampleList.add(new ExampleItem( "8:20 AM বিশ্ববিদ্যালয়-পাচুড়িয়া", string));
                mAdapter = new ExampleAdapter(exampleList);
                mRecyclerView.setLayoutManager(mLayoutManager);
                mRecyclerView.setAdapter(mAdapter);
            }
            else if (9*100+0>=ck && 8*100+20<ck){
                ArrayList<ExampleItem> exampleList = new ArrayList<>();
                String string = timeRem("09:00");
                exampleList.add(new ExampleItem( "9:00 AM বিশ্ববিদ্যালয়-বিশ্বরোড-পুলিশলাইন", string));
                exampleList.add(new ExampleItem( "9:00 AM বিশ্ববিদ্যালয়-লঞ্চঘাট", string));
                exampleList.add(new ExampleItem( "9:00 AM বিশ্ববিদ্যালয়-পাচুড়িয়া",string));
                mAdapter = new ExampleAdapter(exampleList);
                mRecyclerView.setLayoutManager(mLayoutManager);
                mRecyclerView.setAdapter(mAdapter);
            }
            else if (9*100+45>=ck && 9*100+0<ck ){
                ArrayList<ExampleItem> exampleList = new ArrayList<>();
                String string = timeRem("09:45");
                exampleList.add(new ExampleItem( "9:45 AM বিশ্ববিদ্যালয়-কুশলী", string));
                mAdapter = new ExampleAdapter(exampleList);
                mRecyclerView.setLayoutManager(mLayoutManager);
                mRecyclerView.setAdapter(mAdapter);
            }
            else if (13*100+5>=ck && 9*100+45<ck){
                ArrayList<ExampleItem> exampleList = new ArrayList<>();
                String string = timeRem("13:05");
                String string1 = timeRem("13:10");
                exampleList.add(new ExampleItem(  "1:05 PM বিশ্ববিদ্যালয়-শহর-পুলিশলাইন [এসি]", string));
                exampleList.add(new ExampleItem( "1:10 PM বিশ্ববিদ্যালয়-শহর-পুলিশলাইন", string1));
                exampleList.add(new ExampleItem( "1:10 PM বিশ্ববিদ্যালয়-লঞ্চঘাট", string1));
                mAdapter = new ExampleAdapter(exampleList);
                mRecyclerView.setLayoutManager(mLayoutManager);
                mRecyclerView.setAdapter(mAdapter);
            }
            else if (13*100+10>=ck && 13*100+05<ck ){
                ArrayList<ExampleItem> exampleList = new ArrayList<>();
                String string = timeRem("13:10");
                exampleList.add(new ExampleItem( "1:10 PM বিশ্ববিদ্যালয়-শহর-পুলিশলাইন", string));
                exampleList.add(new ExampleItem( "1:10 PM বিশ্ববিদ্যালয়-লঞ্চঘাট", string));
                mAdapter = new ExampleAdapter(exampleList);
                mRecyclerView.setLayoutManager(mLayoutManager);
                mRecyclerView.setAdapter(mAdapter);
            }
            else if (14*100+10>=ck && 13*100+10<ck){
                ArrayList<ExampleItem> exampleList = new ArrayList<>();
                String string = timeRem("14:10");
                exampleList.add(new ExampleItem( "2:10 PM বিশ্ববিদ্যালয়-শহর-পুলিশলাইন", string));
                mAdapter = new ExampleAdapter(exampleList);
                mRecyclerView.setLayoutManager(mLayoutManager);
                mRecyclerView.setAdapter(mAdapter);
            }
            else if (17*100+10>=ck && 14*100+10<ck){
            ArrayList<ExampleItem> exampleList = new ArrayList<>();
            String string = timeRem("17:10");
            exampleList.add(new ExampleItem( "5:10 PM বিশ্ববিদ্যালয়-শহর-কাশিয়ানী", string));
            exampleList.add(new ExampleItem( "5:10 AM বিশ্ববিদ্যালয়-শহর-পুলিশলাইন-সাতপাড়", string));
            exampleList.add(new ExampleItem( "5:10 AM বিশ্ববিদ্যালয়-বেদগ্রাম-কোটালিপাড়া", string));
            exampleList.add(new ExampleItem( "5:10 PM বিশ্ববিদ্যালয়-ঘোনাপাড়া-টুঙ্গিপাড়া", string));
            exampleList.add(new ExampleItem( "5:10 PM বিশ্ববিদ্যালয়-শহর-পুলিশলাইন [এসি]", string));
            exampleList.add(new ExampleItem( "5:10 PM বিশ্ববিদ্যালয়-শহর-পুলিশলাইন", string));
            exampleList.add(new ExampleItem( "5:10 PM বিশ্ববিদ্যালয়-লঞ্চঘাট", string));
            exampleList.add(new ExampleItem( "5:10 PM বিশ্ববিদ্যালয়-সোনাডাঙ্গা,খুলনা", string));
            mRecyclerView.setHasFixedSize(true);
            mLayoutManager = new LinearLayoutManager(this);
            mAdapter = new ExampleAdapter(exampleList);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mAdapter);
            }
            else if (20*100+10>=ck && 17*100+10<ck){
            ArrayList<ExampleItem> exampleList = new ArrayList<>();
                String string = timeRem("20:10");
            exampleList.add(new ExampleItem( "8:10 PM বিশ্ববিদ্যালয়-লঞ্চঘাট", string));
            mAdapter = new ExampleAdapter(exampleList);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mAdapter);
            }
            else if (23*100+59>=ck && 20*100+10<ck){
                ArrayList<ExampleItem> exampleList = new ArrayList<>();
                exampleList.add(new ExampleItem( "7:00 AM বিশ্ববিদ্যালয়-শহর-কাশিয়ানী-পোনা", " Next Day  "));
                exampleList.add(new ExampleItem( "7:00 AM বিশ্ববিদ্যালয়-শহর-সাতপাড়",  " Next Day  "));
                exampleList.add(new ExampleItem( "7:15 AM বিশ্ববিদ্যালয়-বিশ্বরোড-পুলিশলাইন",  " Next Day  "));
                exampleList.add(new ExampleItem( "7:15 AM বিশ্ববিদ্যালয়-বিশ্বরোড-কোটালিপাড়া",  " Next Day  "));
                mAdapter = new ExampleAdapter(exampleList);
                mRecyclerView.setLayoutManager(mLayoutManager);
                mRecyclerView.setAdapter(mAdapter);
            }

    }
    public void compareDates1(int ck){
        mRecyclerView = findViewById(R.id.recyclerView2);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        if (7*100+40>=ck && 0<=ck) {
            ArrayList<ExampleItem> exampleList = new ArrayList<>();

            String string = timeRem("07:40");
            String string1 = timeRem("07:50");
            String string2 = timeRem("08:00");

            exampleList.add(new ExampleItem( "7:40 AM পুলিশলাইন-শহর-বিশ্ববিদ্যালয়-টুঙ্গিপাড়া", string));
            exampleList.add(new ExampleItem( "7:50 AM পোনা-কাশিয়ানী-শহর-বিশ্ববিদ্যালয়", string1));
            exampleList.add(new ExampleItem( "8:00 AM কোটালিপাড়া-বিশ্বরোড-বিশ্ববিদ্যালয়", string2));
            exampleList.add(new ExampleItem( "8:00 AM সাতপাড়-পুলিশলাইন-শহর-বিশ্ববিদ্যালয়", string2));
            mAdapter = new ExampleAdapter(exampleList);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mAdapter);
            }
            else if (7*100+50>=ck && 7*100+40<ck) {
            ArrayList<ExampleItem> exampleList = new ArrayList<>();

            String string1 = timeRem("07:50");
            String string2 = timeRem("08:00");

            exampleList.add(new ExampleItem( "7:50 AM পোনা-কাশিয়ানী-শহর-বিশ্ববিদ্যালয়",string1));
            exampleList.add(new ExampleItem( "8:00 AM কোটালিপাড়া-বিশ্বরোড-বিশ্ববিদ্যালয়", string2));
            exampleList.add(new ExampleItem( "8:00 AM সাতপাড়-পুলিশলাইন-শহর-বিশ্ববিদ্যালয়", string2));
            mAdapter = new ExampleAdapter(exampleList);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mAdapter);
            }
            else if (8*100+0>=ck && 7*100+50<ck) {
            ArrayList<ExampleItem> exampleList = new ArrayList<>();
            String string1 = timeRem("08:00");

            exampleList.add(new ExampleItem( "8:00 AM কোটালিপাড়া-বিশ্বরোড-বিশ্ববিদ্যালয়", string1));
            exampleList.add(new ExampleItem( "8:00 AM সাতপাড়-পুলিশলাইন-শহর-বিশ্ববিদ্যালয়", string1));
            mAdapter = new ExampleAdapter(exampleList);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mAdapter);
            }

            else if (8*100+30>=ck && 8*100+00<ck) {
            ArrayList<ExampleItem> exampleList = new ArrayList<>();
            String string1 = timeRem("08:30");
            String string2 = timeRem("08:35");
            String string3 = timeRem("08:40");
            exampleList.add(new ExampleItem(  "8:30 AM টুঙ্গিপাড়া-ঘোনাপাড়া-বিশ্ববিদ্যালয়", string1));
            exampleList.add(new ExampleItem( "8:30 AM পুলিশলাইন-শহর-বিশ্ববিদ্যালয়", string1));
            exampleList.add(new ExampleItem( "8:35 AM পুলিশলাইন-শহর-বিশ্ববিদ্যালয় [এসি]", string2));
            exampleList.add(new ExampleItem("8:35 AM লঞ্চঘাট-বিশ্ববিদ্যালয়", string2));
            exampleList.add(new ExampleItem("8:40 AM পাচুড়িয়া-বিশ্ববিদ্যালয়", string3));
            mAdapter = new ExampleAdapter(exampleList);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mAdapter);
            }
            else if (8*100+35>=ck && 8*100+30<ck) {
            ArrayList<ExampleItem> exampleList = new ArrayList<>();
            String string2 = timeRem("08:35");
            String string3 = timeRem("08:40");
            exampleList.add(new ExampleItem( "8:35 AM পুলিশলাইন-শহর-বিশ্ববিদ্যালয় [এসি]", string2));
            exampleList.add(new ExampleItem("8:35 AM লঞ্চঘাট-বিশ্ববিদ্যালয়", string2));
            exampleList.add(new ExampleItem("8:40 AM পাচুড়িয়া-বিশ্ববিদ্যালয়", string3));
            mAdapter = new ExampleAdapter(exampleList);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mAdapter);
            }
            else if (8*100+40>=ck && 8*100+35<ck) {
            ArrayList<ExampleItem> exampleList = new ArrayList<>();
            String string3 = timeRem("08:40");
            exampleList.add(new ExampleItem("8:40 AM পাচুড়িয়া-বিশ্ববিদ্যালয়", string3));
            mAdapter = new ExampleAdapter(exampleList);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mAdapter);
            }
            else if (9*100+15>=ck && 8*100+40<ck ) {
            ArrayList<ExampleItem> exampleList = new ArrayList<>();
            String string1 = timeRem("09:15");
            String string2 = timeRem("09:20");
            String string3 = timeRem("09:25");
            exampleList.add(new ExampleItem("9:15 AM পুলিশলাইন-শহর-বিশ্ববিদ্যালয়", string1));
            exampleList.add(new ExampleItem("9:20 AM লঞ্চঘাট-বিশ্ববিদ্যালয়", string2));
            exampleList.add(new ExampleItem("9:25 AM পাচুড়িয়া-বিশ্ববিদ্যালয়", string3));
            mAdapter = new ExampleAdapter(exampleList);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mAdapter);
            }
            else if (9*100+20>=ck && 9*100+15<ck ) {
                ArrayList<ExampleItem> exampleList = new ArrayList<>();
            String string2 = timeRem("09:20");
            String string3 = timeRem("09:25");
            exampleList.add(new ExampleItem("9:20 AM লঞ্চঘাট-বিশ্ববিদ্যালয়", string2));
            exampleList.add(new ExampleItem("9:25 AM পাচুড়িয়া-বিশ্ববিদ্যালয়", string3));
            mAdapter = new ExampleAdapter(exampleList);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mAdapter);
            }
            else if (9*100+25>=ck && 9*100+20<ck ) {
            ArrayList<ExampleItem> exampleList = new ArrayList<>();
            String string3 = timeRem("09:25");
            exampleList.add(new ExampleItem("9:25 AM পাচুড়িয়া-বিশ্ববিদ্যালয়", string3));
            mAdapter = new ExampleAdapter(exampleList);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mAdapter);
            }
            else if (12*100+45>=ck && 9*100+25<ck) {
            ArrayList<ExampleItem> exampleList = new ArrayList<>();

            String string1 = timeRem("12:45");
            String string2 = timeRem("13:30");
            String string3 = timeRem("13:40");
            String string4 = timeRem("13:45");

            exampleList.add(new ExampleItem("12:45 PM কুশলী-বিশ্ববিদ্যালয়", string1));
            exampleList.add(new ExampleItem("1:30 PM পুলিশলাইন-বিশ্বরোড-বিশ্ববিদ্যালয়", string2));
            exampleList.add(new ExampleItem("1:40 PM লঞ্চঘাট-বিশ্ববিদ্যালয়", string3));
            exampleList.add(new ExampleItem("1:45 PM পুলিশলাইন-বিশ্বরোড-বিশ্ববিদ্যালয় [এসি]", string4));

            mAdapter = new ExampleAdapter(exampleList);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mAdapter);
            }
            else if (13*100+30>=ck && 12*100+45<ck) {
            ArrayList<ExampleItem> exampleList = new ArrayList<>();

            String string2 = timeRem("13:30");
            String string3 = timeRem("13:40");
            String string4 = timeRem("13:45");

            exampleList.add(new ExampleItem("1:30 PM পুলিশলাইন-বিশ্বরোড-বিশ্ববিদ্যালয়", string2));
            exampleList.add(new ExampleItem("1:40 PM লঞ্চঘাট-বিশ্ববিদ্যালয়", string3));
            exampleList.add(new ExampleItem("1:45 PM পুলিশলাইন-বিশ্বরোড-বিশ্ববিদ্যালয় [এসি]", string4));

            mAdapter = new ExampleAdapter(exampleList);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mAdapter);
            }
            else if (13*100+40>=ck && 13*100+30<ck) {
            ArrayList<ExampleItem> exampleList = new ArrayList<>();
            String string3 = timeRem("13:40");
            exampleList.add(new ExampleItem("1:40 PM লঞ্চঘাট-বিশ্ববিদ্যালয়", string3));
            exampleList.add(new ExampleItem("1:45 PM পুলিশলাইন-বিশ্বরোড-বিশ্ববিদ্যালয় [এসি]", "TIME REMAIN : 0 h: 0 min"));
            mAdapter = new ExampleAdapter(exampleList);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mAdapter);
            }
            else if (13*100+45>=ck && 13*100+40<ck) {
            ArrayList<ExampleItem> exampleList = new ArrayList<>();
            String string3 = timeRem("13:45");
            String string4 = timeRem("14:40");
            exampleList.add(new ExampleItem("1:45 PM পুলিশলাইন-বিশ্বরোড-বিশ্ববিদ্যালয় [এসি]", string3));
            exampleList.add(new ExampleItem("2:40 PM পুলিশলাইন-বিশ্বরোড-বিশ্ববিদ্যালয়", string4));
            mAdapter = new ExampleAdapter(exampleList);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mAdapter);
            }
            else if (14*100+40>=ck && 13*100+45<ck) {
            ArrayList<ExampleItem> exampleList = new ArrayList<>();
            String string4 = timeRem("14:40");
            exampleList.add(new ExampleItem("2:40 PM পুলিশলাইন-বিশ্বরোড-বিশ্ববিদ্যালয়", string4));
            mAdapter = new ExampleAdapter(exampleList);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mAdapter);
            }
            else if (17*100+30>=ck && 14*100+40<ck) {
            String string1 = timeRem("17:30");
            String string2 = timeRem("17:40");
            String string3 = timeRem("18:00");
            ArrayList<ExampleItem> exampleList = new ArrayList<>();
            exampleList.add(new ExampleItem("5:30 PM পুলিশলাইন-বিশ্বরোড-বিশ্ববিদ্যালয় [এসি]", string1));
            exampleList.add(new ExampleItem("5:30 PM পুলিশলাইন-বিশ্বরোড-বিশ্ববিদ্যালয়", string1));
            exampleList.add(new ExampleItem("5:30 PM লঞ্চঘাট-বিশ্ববিদ্যালয়", string1));
            exampleList.add(new ExampleItem("5:40 PM টুঙ্গিপাড়া-ঘোনাপাড়া-বিশ্ববিদ্যালয়", string2));
            exampleList.add(new ExampleItem("6:00 PM কোটালিপাড়া-বেদগ্রাম-বিশ্ববিদ্যালয়", string3));
            mAdapter = new ExampleAdapter(exampleList);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mAdapter);

            }
            else if (17*100+40>=ck && 14*100+30<ck) {
            ArrayList<ExampleItem> exampleList = new ArrayList<>();

            String string2 = timeRem("17:40");
            String string3 = timeRem("18:00");
            exampleList.add(new ExampleItem("5:40 PM টুঙ্গিপাড়া-ঘোনাপাড়া-বিশ্ববিদ্যালয়", string2));
            exampleList.add(new ExampleItem("6:00 PM কোটালিপাড়া-বেদগ্রাম-বিশ্ববিদ্যালয়", string3));

            mAdapter = new ExampleAdapter(exampleList);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mAdapter);
            }
            else if (18*100+0>=ck && 17*100+40<ck ) {
            ArrayList<ExampleItem> exampleList = new ArrayList<>();
            String string3 = timeRem("18:00");
            exampleList.add(new ExampleItem("6:00 PM কোটালিপাড়া-বেদগ্রাম-বিশ্ববিদ্যালয়", string3));
            mAdapter = new ExampleAdapter(exampleList);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mAdapter);
            }
            else if (20*100+30>=ck && 18*100+0<ck ) {
            ArrayList<ExampleItem> exampleList = new ArrayList<>();
            String string3 = timeRem("20:30");
            exampleList.add(new ExampleItem("8:30 PM লঞ্চঘাট-বিশ্ববিদ্যালয়",string3));
            mAdapter = new ExampleAdapter(exampleList);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mAdapter);
            }
            else if (23*100+59>=ck && 20*100+30<ck ) {
            ArrayList<ExampleItem> exampleList = new ArrayList<>();

            exampleList.add(new ExampleItem( "7:40 AM পুলিশলাইন-শহর-বিশ্ববিদ্যালয়-টুঙ্গিপাড়া", " Next Day  "));
            exampleList.add(new ExampleItem( "7:50 AM পোনা-কাশিয়ানী-শহর-বিশ্ববিদ্যালয়", " Next Day  "));
            exampleList.add(new ExampleItem( "8:00 AM কোটালিপাড়া-বিশ্বরোড-বিশ্ববিদ্যালয়", " Next Day  "));
            exampleList.add(new ExampleItem( "8:00 AM সাতপাড়-পুলিশলাইন-শহর-বিশ্ববিদ্যালয়", " Next Day  "));

            mAdapter = new ExampleAdapter(exampleList);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setAdapter(mAdapter);
            }
        }
    public String timeRem(String target){
        String result = "";
        try{
            SimpleDateFormat format = new SimpleDateFormat("HH:mm");
            Calendar now = Calendar.getInstance();
            int hour = now.get(Calendar.HOUR_OF_DAY); // Get hour in 24 hour format
            int minute = now.get(Calendar.MINUTE);
            Date date1 = format.parse(hour + ":" + minute);
            Date date2 = format.parse(target);
            long present = date2.getTime() - date1.getTime();
            present/=1000;
            long hours = present / (60 * 60) % 24;
            long minutes = present / 60 % 60;
            if(hours!=0)
            result = hours + " H : " +minutes +" M  ";
            else
                result = minutes +" M  ";
        }catch (Exception e){
        }
        return result;
        }
    }

