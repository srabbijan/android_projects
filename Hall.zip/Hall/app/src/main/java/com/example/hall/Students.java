package com.example.hall;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.core.Context;

public class Students extends AppCompatActivity {
    private AutoCompleteTextView mSearchField;
    Spinner spinner;
    private ImageButton mSearchBtn;
    Vibrator vibrator;
    private RecyclerView mResultList;
    String searchBy;
    private DatabaseReference mUserDatabase;
    String[] strSName = {"Computer Science and Engineering","Electrical and Electronic Engineering","Electronics and Telecommunication Engineering","Applied Chemistry and Chemical Engineering",
            "Civil Engineering","Food and Agro-process Engineering", "Architecture","Social Science Faculty","Sociology", "Public Administration","International Relations","Economics",
            "Political Science","Mathematics","Statistics","Chemistry","Physics", "Environmental Science & Disaster Management","Management Studies",
            "Accounting and Information Systems","Marketing","Finance and Banking", "Tourism and Hospitality Management","Pharmacy","Biotechnology and Genetic Engineering",
            "Biochemistry and Molecular Biology","Psychology","Botany","Law", "English","Bangla","Agriculture","Fisheries and Marine Bioscience",
            "Livestock Science and Veterinary Medicine","501","502","503","504","505","506","507","508","Gono Room "};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_students);

        mUserDatabase = FirebaseDatabase.getInstance().getReference("students");
        mUserDatabase.keepSynced(true);

        getSupportActionBar().setTitle("Search Students");

        spinner = findViewById(R.id.student_spiner);
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        mSearchField =  findViewById(R.id.search_field);
        mSearchBtn =  findViewById(R.id.search_btn);
        mResultList =  findViewById(R.id.student_list);

        mResultList.setHasFixedSize(true);
        mResultList.setLayoutManager(new LinearLayoutManager(this));

        final String[] units = {"Search by Room","Search by Department"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,units);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i)
                {
                    case 0:
                        searchBy = "room";
                        break;
                    case 1:
                        searchBy = "department";
                        break;
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        StringBuilder desi = new StringBuilder();
        desi.append("Input Value").append("\n");
        for (String value:strSName){
            desi.append(value).append(",");
        }
        ArrayAdapter arrayAdapterDesi = new ArrayAdapter(this,android.R.layout.simple_list_item_1,strSName);
        mSearchField.setAdapter(arrayAdapterDesi);
        mSearchField.setThreshold(1);
        mSearchField.setAdapter(arrayAdapterDesi);

        mSearchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String searchText = mSearchField.getText().toString();
                if(searchText.isEmpty()){
                    vibrate();
                    Toast.makeText(Students.this, "Dept. / Room is not Empty\nPlease Enter Valid Dept. / Room No.", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    firebaseUserSearch(searchBy,searchText);
                    closeKeyboard();
                }
            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.add,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.notfication:
            {
                Intent intent = new Intent(Students.this, StudentDataAdd.class);
                startActivity(intent);
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }
    private void firebaseUserSearch(String searchBy,String searchText) {

        Toast.makeText(Students.this, "Searching", Toast.LENGTH_LONG).show();

        Query firebaseSearchQuery = mUserDatabase.orderByChild(searchBy).startAt(searchText).endAt(searchText + "\uf8ff");
        FirebaseRecyclerAdapter<Users, UsersViewHolder> firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<Users, UsersViewHolder>(
                Users.class,
                R.layout.student_list_card,
                UsersViewHolder.class,
                firebaseSearchQuery) {
            @Override
            protected void populateViewHolder(UsersViewHolder viewHolder, Users model, int position) {

                viewHolder.setDetails(getApplicationContext(),
                        model.getName(),
                        model.getDepartment(),
                        model.getRoll(),
                        model.getPhone(),
                        model.getHomeTown(),
                        model.getRoom());
            }
        };
        mResultList.setAdapter(firebaseRecyclerAdapter);
    }
    public static class UsersViewHolder extends RecyclerView.ViewHolder {

        View mView;
        public UsersViewHolder(View itemView) {
            super(itemView);
            mView = itemView;

        }
        public void setDetails(android.content.Context applicationContext,
                               String name,
                               String department,
                               String roll,
                               String phone,
                               String homeTown,
                               String room) {
            TextView tv_name = mView.findViewById(R.id.student_name);
            tv_name.setText(name);
            TextView tv_dept = mView.findViewById(R.id.student_department);
            tv_dept.setText(department);
            TextView tv_roll = mView.findViewById(R.id.student_roll);
            tv_roll.setText(roll);
            TextView tv_phone = mView.findViewById(R.id.student_phone);
            tv_phone.setText(phone);
            TextView tv_home = mView.findViewById(R.id.student_homeTown);
            tv_home.setText(homeTown);
            TextView tv_room = mView.findViewById(R.id.student_roomNo);
            tv_room.setText(room);
        }
    }
    private void vibrate(){
        if(Build.VERSION.SDK_INT>=26){
            vibrator.vibrate(VibrationEffect.createOneShot(200,VibrationEffect.DEFAULT_AMPLITUDE));
        }
        else
            vibrator.vibrate(200);
    }
    private void closeKeyboard(){
        View view = this.getCurrentFocus();
        if(view!=null){
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(),0);
        }
    }
}

