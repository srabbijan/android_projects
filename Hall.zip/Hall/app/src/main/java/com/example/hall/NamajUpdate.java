package com.example.hall;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;

public class NamajUpdate extends AppCompatActivity {

    AutoCompleteTextView s_name;
    TimePicker s_time;
    Button s_update;
    String format = " ";
    private DatabaseReference databaseReference;

    String[] strSName = {"Salat al Fajr","Salat al Zuhr","Salat al Asr","Salat al Maghrib","Salat al Isha"};
    String SALATNAME,SALATTIME;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_namaj_update);

        getSupportActionBar().setTitle("Update Salat Time");

        s_name = findViewById(R.id.namaj_name);
        s_time = findViewById(R.id.namaj_time);
        s_update =findViewById(R.id.namaj_update);

        StringBuilder desi = new StringBuilder();
        desi.append("Input Value").append("\n");
        for (String value:strSName){
            desi.append(value).append(",");
        }
        ArrayAdapter arrayAdapterDesi = new ArrayAdapter(this,android.R.layout.simple_list_item_1,strSName);
        s_name.setAdapter(arrayAdapterDesi);
        s_name.setThreshold(1);
        s_name.setAdapter(arrayAdapterDesi);

        databaseReference = FirebaseDatabase.getInstance().getReference().child("namaj");
        databaseReference.keepSynced(true);

        s_time.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {

                if (hourOfDay == 0) {
                    hourOfDay += 12;
                    format = " AM";
                } else if (hourOfDay == 12) {
                    format = " PM";
                } else if (hourOfDay > 12) {
                    hourOfDay -= 12;
                    format = " PM";
                } else {
                    format = " AM";
                }
                SALATTIME = Integer.toString(hourOfDay);
                SALATTIME+= " : ";
                SALATTIME+= Integer.toString(minute);
                SALATTIME+= format;
            }
        });
        s_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 SALATNAME = s_name.getText().toString();
                if(cheek(SALATNAME)){
                    Toast.makeText(NamajUpdate.this, SALATTIME, Toast.LENGTH_SHORT).show();
                     editData(SALATNAME, SALATTIME);
                     finish();
                }
            }
        });
    }
    Boolean cheek (String n){
        if (n.isEmpty())
        {Toast.makeText(this, "Please Enter Salat Name", Toast.LENGTH_SHORT).show();
            return false;}
        return true;
    }

    void editData(String s, final String strBody){
        Query editQuery = databaseReference.orderByChild("name").equalTo(s);
        editQuery.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot edtData: dataSnapshot.getChildren()){
                    edtData.getRef().child("time").setValue(strBody);
                }
                Toast.makeText(NamajUpdate.this,"Salat Time Update",Toast.LENGTH_LONG).show();
                s_name.setText("");
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(NamajUpdate.this,databaseError.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
    }
}
