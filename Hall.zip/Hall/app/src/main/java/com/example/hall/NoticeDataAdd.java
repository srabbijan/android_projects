package com.example.hall;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;

public class NoticeDataAdd extends AppCompatActivity {

    EditText notice_person,notice_roll,notice_post;
    Button post;
    DatabaseReference databaseReference;
    NoticeDataGet noticeDataGet;
    String strPerson,strPersonRoll,strPost,DATE;
    Date date;
    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm a");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice_data_add);

        getSupportActionBar().setTitle("Add Post");

        notice_person = findViewById(R.id.notice_person_name);
        notice_roll = findViewById(R.id.notice_person_roll);
        notice_post = findViewById(R.id.notice_post);
        post = findViewById(R.id.notice_add);

        date = new Date();


        databaseReference = FirebaseDatabase.getInstance().getReference().child("notic");
        noticeDataGet = new NoticeDataGet();
        post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                strPerson = notice_person.getText().toString();
                strPersonRoll = notice_roll.getText().toString();
                strPost = notice_post.getText().toString();

                if(cheek(strPerson,strPersonRoll,strPost)){
                    DATE = (String)  formatter.format(date);
                    noticeDataGet.setPerson(strPerson);
                    noticeDataGet.setRoll(strPersonRoll);
                    noticeDataGet.setComment(strPost);
                    noticeDataGet.setDate(DATE);

                    databaseReference.child(strPersonRoll + strPerson).setValue(noticeDataGet);

                    Toast.makeText(NoticeDataAdd.this, "Post Add", Toast.LENGTH_SHORT).show();

                    finish();

                }
            }
        });
    }
    Boolean cheek (String pn, String r, String post){
        if (pn.isEmpty())
        {Toast.makeText(this, "Name is not Empty", Toast.LENGTH_SHORT).show();
            return false;}
        if (r.isEmpty())
        {Toast.makeText(this, "Roll is not Empty", Toast.LENGTH_SHORT).show();
            return false;}
        if (post.isEmpty())
        {Toast.makeText(this, "Post is not Empty", Toast.LENGTH_SHORT).show();
            return false;}
        return true;
    }
}
