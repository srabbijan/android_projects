package com.example.hall;

public class ProvostDataGet {
    private String Name,Phone,Email,Designation,Department;
    public ProvostDataGet(){}
    public ProvostDataGet(String name, String phone, String email, String designation, String department) {
        Name = name;
        Phone = phone;
        Email = email;
        Designation = designation;
        Department = department;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getDesignation() {
        return Designation;
    }

    public void setDesignation(String designation) {
        Designation = designation;
    }

    public String getDepartment() {
        return Department;
    }

    public void setDepartment(String department) {
        Department = department;
    }
}
