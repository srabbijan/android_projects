package com.example.hall;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;


import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class Staff extends AppCompatActivity {

private RecyclerView recyclerView;
private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff);

        databaseReference = FirebaseDatabase.getInstance().getReference().child("staff_list");
        databaseReference.keepSynced(true);

        getSupportActionBar().setTitle("Staff List");

        recyclerView = findViewById(R.id.staff_list);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.add,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.notfication:
            {
                Intent intent = new Intent(Staff.this, StaffDataAdd.class);
                startActivity(intent);
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseRecyclerAdapter<StaffDataGet,StaffDataGetViewHolder> firebaseRecyclerAdapter=new  FirebaseRecyclerAdapter<StaffDataGet,StaffDataGetViewHolder>
                (StaffDataGet.class,R.layout.staff_list_card,StaffDataGetViewHolder.class,databaseReference){
            @Override
            protected void populateViewHolder(StaffDataGetViewHolder staffDataGetViewHolder,StaffDataGet model, int position){
                staffDataGetViewHolder.setName(model.getName());
                staffDataGetViewHolder.setPhone(model.getPhone());
            }
        };
        recyclerView.setAdapter(firebaseRecyclerAdapter);
    }

    public static class StaffDataGetViewHolder extends RecyclerView.ViewHolder{
        View view;
        public StaffDataGetViewHolder(View itemView)
        {
            super(itemView);
            view = itemView;

        }
        public void setName (String name){
            TextView tv_name = view.findViewById(R.id.staff_name);
            tv_name.setText(name);
        }
        public void setPhone (String phone){
            TextView tv_name = view.findViewById(R.id.staff_phone);
            tv_name.setText(phone);
        }
    }

}
