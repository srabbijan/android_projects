package com.example.hall;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ProvostDataAdd extends AppCompatActivity {

    AutoCompleteTextView designation,department;
    EditText name,phone,email,pin;
    Button add;

    String[] Department = {"Computer Science and Engineering","Electrical and Electronic Engineering","Electronics and Telecommunication Engineering","Applied Chemistry and Chemical Engineering",
            "Civil Engineering","Food and Agro-process Engineering", "Architecture","Social Science Faculty","Sociology", "Public Administration","International Relations","Economics",
            "Political Science","Mathematics","Statistics","Chemistry","Physics", "Environmental Science & Disaster Management","Management Studies",
            "Accounting and Information Systems","Marketing","Finance and Banking", "Tourism and Hospitality Management","Pharmacy","Biotechnology and Genetic Engineering",
            "Biochemistry and Molecular Biology","Psychology","Botany","Law", "English","Bangla","Agriculture","Fisheries and Marine Bioscience",
            "Livestock Science and Veterinary Medicine"};
    String[] Designation = {"Professor","Assistant Professor","Lecturer"};
    String strName,strDesignation,strDepartment,strPhone,strEmail,strPin;
    DatabaseReference databaseReference;
    ProvostDataGet provostDataGet;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_provost_data_add);

        getSupportActionBar().setTitle("Add Provost");

        provostDataGet = new ProvostDataGet();
        databaseReference = FirebaseDatabase.getInstance().getReference().child("provost_list");

        name = findViewById(R.id.provost_name_add);
        designation = findViewById(R.id.provost_designation_add);
        department = findViewById(R.id.provost_department_add);
        phone = findViewById(R.id.provost_phone_add);
        email =findViewById(R.id.provost_email_add);
        pin = findViewById(R.id.provost_pin_code);

        add = findViewById(R.id.provost_add);

        StringBuilder desi = new StringBuilder();
        StringBuilder dept = new StringBuilder();

        desi.append("Input Value").append("\n");
        dept.append("Input Value").append("\n");

        for (String value:Designation){
            desi.append(value).append(",");
        }
        for (String value:Department){
            dept.append(value).append(",");
        }

        ArrayAdapter arrayAdapterDesi = new ArrayAdapter(this,android.R.layout.simple_list_item_1,Designation);
        ArrayAdapter arrayAdapterDept = new ArrayAdapter(this,android.R.layout.simple_list_item_1,Department);

        designation.setAdapter(arrayAdapterDesi);
        department.setAdapter(arrayAdapterDept);
        designation.setThreshold(1);
        department.setThreshold(1);
        designation.setAdapter(arrayAdapterDesi);
        department.setAdapter(arrayAdapterDept);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                strName = name.getText().toString();
                strDesignation = designation.getText().toString();
                strDepartment = department.getText().toString();
                strPhone = phone.getText().toString();
                strEmail = email.getText().toString();
                strPin = pin.getText().toString();
                if(cheek(strName,strDesignation,strDepartment,strPhone,strEmail,strPin)){

                    provostDataGet.setName(strName);
                    provostDataGet.setDesignation(strDesignation);
                    provostDataGet.setDepartment(strDepartment);
                    provostDataGet.setPhone(strPhone);
                    provostDataGet.setEmail(strEmail);

                    databaseReference.child(strName+strPhone).setValue(provostDataGet);

                    Toast.makeText(ProvostDataAdd.this, "Provost Add", Toast.LENGTH_SHORT).show();

                    finish();
                }

            }
        });

    }
    Boolean cheek (String n, String d,String dp,String p,String e,String pin){
        if (n.isEmpty())
        {Toast.makeText(this, "Name is not Empty", Toast.LENGTH_SHORT).show();
            return false;}
        if (d.isEmpty())
        {Toast.makeText(this, "Designation is not Empty", Toast.LENGTH_SHORT).show();
            return false;}
        if (dp.isEmpty())
        {Toast.makeText(this, "Department is not Empty", Toast.LENGTH_SHORT).show();
            return false;}

        if (p.isEmpty()||p.length()<11)
        {Toast.makeText(this, "Phone No Should be 11 digit's", Toast.LENGTH_SHORT).show();
            return false;}
        if (e.isEmpty())
        {Toast.makeText(this, "Email is not Empty", Toast.LENGTH_SHORT).show();
            return false;}
        if(!pin.equals("2019"))
        {
            Toast.makeText(this, "Pin is not Valid", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
