package com.example.hall;

public class NoticeDataGet {
    String person,roll,comment,date;

    public String getPerson() {
        return person;
    }

    public void setPerson(String person) {
        this.person = person;
    }

    public String getRoll() {
        return roll;
    }

    public void setRoll(String roll) {
        this.roll = roll;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }



    public NoticeDataGet(String person, String roll, String comment, String date) {
        this.person = person;
        this.roll = roll;
        this.comment = comment;
        this.date = date;
    }
    public NoticeDataGet() {

    }
}
