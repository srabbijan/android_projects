package com.example.hall;

/**
 * Created by AkshayeJH on 15/12/17.
 */

public class Users {

    private String Name,Department,Roll,Phone,HomeTown,Room;

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getDepartment() {
        return Department;
    }

    public void setDepartment(String department) {
        Department = department;
    }

    public String getRoll() {
        return Roll;
    }

    public void setRoll(String roll) {
        Roll = roll;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getHomeTown() {
        return HomeTown;
    }

    public void setHomeTown(String homeTown) {
        HomeTown = homeTown;
    }

    public String getRoom() {
        return Room;
    }

    public void setRoom(String room) {
        Room = room;
    }

    public Users(String name, String department, String roll, String phone, String homeTown, String room) {
        Name = name;
        Department = department;
        Roll = roll;
        Phone = phone;
        HomeTown = homeTown;
        Room = room;
    }

    public Users(){}

}
