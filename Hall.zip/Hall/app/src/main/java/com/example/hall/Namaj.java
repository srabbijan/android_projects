package com.example.hall;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Namaj extends AppCompatActivity {
    private RecyclerView recyclerView;
    private DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_namaj);

        databaseReference = FirebaseDatabase.getInstance().getReference().child("namaj");
        databaseReference.keepSynced(true);

        getSupportActionBar().setTitle("Salat Time");

        recyclerView = findViewById(R.id.namaj_list);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.add,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.notfication:
            {
                Intent intent = new Intent(Namaj.this, NamajUpdate.class);
                startActivity(intent);
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    protected void onStart() {
        super.onStart();

        FirebaseRecyclerAdapter<NamajDataGet, Namaj.NamajDataGetViewHolder> firebaseRecyclerAdapter =
                new  FirebaseRecyclerAdapter<NamajDataGet, Namaj.NamajDataGetViewHolder>
                (NamajDataGet.class,R.layout.namaj_card, Namaj.NamajDataGetViewHolder.class,databaseReference){
            @Override
            protected void populateViewHolder( Namaj.NamajDataGetViewHolder namajDataGetViewHolder, NamajDataGet model, int position){
               namajDataGetViewHolder.setSalatname(model.getName());
               namajDataGetViewHolder.setTime(model.getTime());

            }
        };
        recyclerView.setAdapter(firebaseRecyclerAdapter);
    }

    public static class NamajDataGetViewHolder extends RecyclerView.ViewHolder{
        View view;
        public NamajDataGetViewHolder(View itemView)
        {
            super(itemView);
            view = itemView;
        }
        public void setSalatname (String name){
            TextView tv_name = view.findViewById(R.id.salat_name);
            tv_name.setText(name);
        }
        public void setTime (String time){
            TextView tv_name = view.findViewById(R.id.salat_time);
            tv_name.setText(time);
        }
    }

}
