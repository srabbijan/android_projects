package com.example.hall;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Developermail extends AppCompatActivity {

    EditText edtSubject,edtMessage;
    Button send;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_developermail);
        edtSubject = findViewById(R.id.mail_subject);
        edtMessage = findViewById(R.id.mail_message);
        send = findViewById(R.id.mail_send);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(Intent.ACTION_SEND);
                it.putExtra(Intent.EXTRA_EMAIL,"srabbijan@gmail.com");
                it.putExtra(Intent.EXTRA_SUBJECT,edtSubject.getText().toString());
                it.putExtra(Intent.EXTRA_TEXT,edtSubject.getText().toString());
                it.setType("message/rfc822");
                startActivity(Intent.createChooser(it,"Choose Mail App"));
            }
        });
    }
}
