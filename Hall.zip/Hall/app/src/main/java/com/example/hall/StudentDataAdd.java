package com.example.hall;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class StudentDataAdd extends AppCompatActivity {
    AutoCompleteTextView room,department,home;

    EditText name,phone,roll;
    Button add;
    String[] strDepartment = {"Computer Science and Engineering","Electrical and Electronic Engineering","Electronics and Telecommunication Engineering","Applied Chemistry and Chemical Engineering",
            "Civil Engineering","Food and Agro-process Engineering", "Architecture","Social Science Faculty","Sociology",
            "Public Administration","International Relations","Economics", "Political Science","Mathematics","Statistics","Chemistry","Physics",
            "Environmental Science & Disaster Management","Management Studies", "Accounting and Information Systems","Marketing","Finance and Banking",
            "Tourism and Hospitality Management","Pharmacy","Biotechnology and Genetic Engineering", "Biochemistry and Molecular Biology","Psychology","Botany","Law",
            "English","Bangla","Agriculture","Fisheries and Marine Bioscience", "Livestock Science and Veterinary Medicine"};

    String[] strRoom = {"501","502","503","504","505","506","507","508","Gono Room "};


    String[] strHome = {"Barguna", "Barisal", "Bhola", "Jhalokati", "Patuakhali", "Pirojpur", "Bandarban", "Brahamanbaria", "Chandpur", "Chittagong", "Comilla", "CoxS Bazar", "Feni", "Khagrachhari",
            "Lakshmipur", "Noakhali", "Rangamati", "Dhaka", "Faridpur", "Gazipur", "Gopalganj", "Jamalpur", "Kishoreganj", "Madaripur", "Manikganj", "Munshiganj", "Mymensingh", "Narayanganj", "Narsingdi", "Netrakona", "Rajbari",
            "Shariatpur", "Sherpur", "Tangail", "Bagerhat", "Chuadanga", "Jessore", "Jhenaidah", "Khulna", "Kushtia", "Magura", "Meherpur", "Narail", "Satkhira", "Bogra", "Joypurhat", "Naogaon", "Natore", "Nawabganj", "Pabna",
            "Rajshahi", "Sirajganj", "Dinajpur", "Gaibandha", "Kurigram", "Lalmonirhat", "Nilphamari", "Panchagarh", "Rangpur", "Thakurgaon", "Habiganj", "Maulvibazar", "Sunamganj", "Sylhet"};

    DatabaseReference databaseReference;
    String strNAME,strDEPT,strROLL,strPHONE,strHOME,strROOM;
    StudentsDataGet provostDataGet;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_data_add);

        getSupportActionBar().setTitle("Add Student");
        provostDataGet = new StudentsDataGet();
        databaseReference = FirebaseDatabase.getInstance().getReference().child("students");



        name = findViewById(R.id.student_name_add);
        department = findViewById(R.id.student_department_add);
        roll = findViewById(R.id.student_roll_add);
        phone = findViewById(R.id.student_phone_add);
        home =findViewById(R.id.student_home_add);
        room =findViewById(R.id.student_room_add);
        add = findViewById(R.id.student_add);

        StringBuilder roomBuffer = new StringBuilder();
        StringBuilder deptBuffer = new StringBuilder();
        StringBuilder homeBuffer = new StringBuilder();

        roomBuffer.append("Input Value").append("\n");
        deptBuffer.append("Input Value").append("\n");
        homeBuffer.append("Input Value").append("\n");

        for (String value:strDepartment){
            deptBuffer.append(value).append(",");
        }
        for (String value:strRoom){
            roomBuffer.append(value).append(",");
        }
        for (String value:strHome){
            homeBuffer.append(value).append(",");
        }

        ArrayAdapter arrayAdapterdept = new ArrayAdapter(this,android.R.layout.simple_list_item_1,strDepartment);
        ArrayAdapter arrayAdapterroom = new ArrayAdapter(this,android.R.layout.simple_list_item_1,strRoom);
        ArrayAdapter arrayAdapterhome = new ArrayAdapter(this,android.R.layout.simple_list_item_1,strHome);

        department.setAdapter(arrayAdapterdept);
        room.setAdapter(arrayAdapterroom);
        home.setAdapter(arrayAdapterhome);

        department.setThreshold(1);
        room.setThreshold(1);
        home.setThreshold(1);


        department.setAdapter(arrayAdapterdept);
        room.setAdapter(arrayAdapterroom);
        home.setAdapter(arrayAdapterhome);



        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                strNAME = name.getText().toString();
                strDEPT = department.getText().toString();
                strROLL = roll.getText().toString();
                strPHONE = phone.getText().toString();
                strHOME = home.getText().toString();
                strROOM = room.getText().toString();

                if(cheek(strNAME,strDEPT,strROLL,strPHONE,strHOME,strROOM))
               {
                    provostDataGet.setName(strNAME);
                    provostDataGet.setDepartment(strDEPT);
                    provostDataGet.setRoll(strROLL);
                    provostDataGet.setPhone(strPHONE);
                    provostDataGet.setHomeTown(strHOME);
                    provostDataGet.setRoom(strROOM);

                    databaseReference.child(strROOM+strNAME+strPHONE).setValue(provostDataGet);

                    Toast.makeText(StudentDataAdd.this, "Data insert", Toast.LENGTH_SHORT).show();

                    name.setText("");
                    roll.setText("");
                    department.setText("");
                    phone.setText("");
                    home.setText("");
                    room.setText("");
                }

            }
        });
    }
    Boolean cheek (String n, String d,String r,String p,String h,String room){
        if (n.isEmpty())
        {Toast.makeText(this, "Name is not Empty", Toast.LENGTH_SHORT).show();
            return false;}
        if (d.isEmpty())
        {Toast.makeText(this, "Department is not Empty", Toast.LENGTH_SHORT).show();
            return false;}
        if (r.isEmpty())
        {Toast.makeText(this, "Roll is not Empty", Toast.LENGTH_SHORT).show();
            return false;}
        if (p.isEmpty()||p.length()<11)
        {Toast.makeText(this, "Phone No Should be 11 digit's", Toast.LENGTH_SHORT).show();
            return false;}
        if (h.isEmpty())
        {Toast.makeText(this, "Home Town is not Empty", Toast.LENGTH_SHORT).show();
            return false;}
        if (room.isEmpty())
        {Toast.makeText(this, "Room No. is not Empty", Toast.LENGTH_SHORT).show();
            return false;}
        return true;
    }
}
