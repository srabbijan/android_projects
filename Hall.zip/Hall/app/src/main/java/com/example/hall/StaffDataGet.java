package com.example.hall;

public class StaffDataGet {
    private String Name;
    private String Phone;

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public StaffDataGet(String name, String phone) {
        this.Name = name;
        this.Phone = phone;
    }
    public StaffDataGet() {

    }


}
