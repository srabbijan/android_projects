package com.example.hall;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Provost extends AppCompatActivity {
    private RecyclerView recyclerView;
    private DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_provost);

        getSupportActionBar().setTitle("Provost List");

        databaseReference = FirebaseDatabase.getInstance().getReference().child("provost_list");
        databaseReference.keepSynced(true);

        recyclerView = findViewById(R.id.provost_list);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.add,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.notfication:
            {
                Intent intent = new Intent(Provost.this, ProvostDataAdd.class);
                startActivity(intent);
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    protected void onStart() {
        super.onStart();
        FirebaseRecyclerAdapter<ProvostDataGet, Provost.ProvostDataGetViewHolder> firebaseRecyclerAdapter = new  FirebaseRecyclerAdapter<ProvostDataGet, Provost.ProvostDataGetViewHolder>
                (ProvostDataGet.class,R.layout.provost_list_card, Provost.ProvostDataGetViewHolder.class,databaseReference){
            @Override
            protected void populateViewHolder(Provost.ProvostDataGetViewHolder ProvostDataGetViewHolder, ProvostDataGet model, int position){
                ProvostDataGetViewHolder.setName(model.getName());
                ProvostDataGetViewHolder.setDesignation(model.getDesignation());
                ProvostDataGetViewHolder.setDepartment(model.getDepartment());
                ProvostDataGetViewHolder.setEmail(model.getEmail());
                ProvostDataGetViewHolder.setPhone(model.getPhone());
            }
        };
        recyclerView.setAdapter(firebaseRecyclerAdapter);
    }

    public static class ProvostDataGetViewHolder extends RecyclerView.ViewHolder{
        View view;
        public ProvostDataGetViewHolder(View itemView)
        {
            super(itemView);
            view = itemView;

        }
        public void setName (String name){
            TextView tv_name = view.findViewById(R.id.provost_name);
            tv_name.setText(name);
        }
        public void setDesignation (String designation){
            TextView tv_name = view.findViewById(R.id.provost_designation);
            tv_name.setText(designation);
        }
        public void setDepartment (String department){
            TextView tv_name = view.findViewById(R.id.provost_department);
            tv_name.setText(department);
        }
        public void setEmail (String email){
            TextView tv_name = view.findViewById(R.id.provost_email);
            tv_name.setText(email);
        }
        public void setPhone (String phone){
            TextView tv_name = view.findViewById(R.id.provost_phone);
            tv_name.setText(phone);
        }
    }

}
