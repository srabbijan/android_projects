package com.example.hall;

public class NamajDataGet {
    String name,time;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public NamajDataGet(String salatname, String time) {
        this.name = salatname;
        this.time = time;
    }
    public NamajDataGet() {
    }
}
