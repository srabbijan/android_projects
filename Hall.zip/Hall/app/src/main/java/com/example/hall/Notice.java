package com.example.hall;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Notice extends AppCompatActivity {
    private RecyclerView recyclerView;
    private DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice);
        databaseReference = FirebaseDatabase.getInstance().getReference().child("notic");
        databaseReference.keepSynced(true);

        getSupportActionBar().setTitle("Notice Board");

        recyclerView = findViewById(R.id.notice_list);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.add,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.notfication:
            {
                Intent intent = new Intent(Notice.this, NoticeDataAdd.class);
                startActivity(intent);
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseRecyclerAdapter<NoticeDataGet, Notice.NoticeDataGetViewHolder> firebaseRecyclerAdapter =
                new  FirebaseRecyclerAdapter<NoticeDataGet, Notice.NoticeDataGetViewHolder>
                (NoticeDataGet.class,R.layout.notice_list_card, Notice.NoticeDataGetViewHolder.class,databaseReference){
            @Override
            protected void populateViewHolder(Notice.NoticeDataGetViewHolder noticeDataGetViewHolder, NoticeDataGet model, int position){
                noticeDataGetViewHolder.setPerson(model.getPerson());
                noticeDataGetViewHolder.setRoll(model.getRoll());
                noticeDataGetViewHolder.setComment(model.getComment());
                noticeDataGetViewHolder.setDate(model.getDate());
            }
        };
        recyclerView.setAdapter(firebaseRecyclerAdapter);
    }

    public static class NoticeDataGetViewHolder extends RecyclerView.ViewHolder{
        View view;
        public NoticeDataGetViewHolder(View itemView)
        {
            super(itemView);
            view = itemView;
        }
        public void setPerson (String person){
            TextView tv_name = view.findViewById(R.id.notice_person);
            tv_name.setText(person);
        }
        public void setRoll (String roll){
            TextView tv_name = view.findViewById(R.id.notice_roll);
            tv_name.setText(roll);
        }
        public void setComment (String comment){
            TextView tv_name = view.findViewById(R.id.notice_comment);
            tv_name.setText(comment);
        }
        public void setDate (String date){
            TextView tv_name = view.findViewById(R.id.notice_date);
            tv_name.setText(date);
        }
    }

}
