package com.example.hall;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class StaffDataAdd extends AppCompatActivity {

    EditText staff_Name,staff_phone;
    Button add;
    DatabaseReference databaseReference;
    StaffDataGet staffDataGet;
    String Name,Phone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_data_add);

        getSupportActionBar().setTitle("Add Staff");

        staff_Name = findViewById(R.id.staff_name_add);
        staff_phone = findViewById(R.id.staff_phone_add);
        add = findViewById(R.id.staff_add);



        staffDataGet = new StaffDataGet();

        databaseReference = FirebaseDatabase.getInstance().getReference().child("staff_list");

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Name = staff_Name.getText().toString();
                Phone = staff_phone.getText().toString();

                if(cheek(Name,Phone)){

                        staffDataGet.setName(Name);
                        staffDataGet.setPhone(Phone);

                        databaseReference.child(Name + Phone).setValue(staffDataGet);

                        Toast.makeText(StaffDataAdd.this, "Data insert", Toast.LENGTH_SHORT).show();

                        staff_Name.setText("");
                        staff_phone.setText("");

                    }

            }
        });
    }
    Boolean cheek (String n, String p){
        if (n.isEmpty())
        {Toast.makeText(this, "Name is not Empty", Toast.LENGTH_SHORT).show();
            return false;}
        if (p.isEmpty()||p.length()<11)
        {Toast.makeText(this, "Phone No Should be 11 digit's", Toast.LENGTH_SHORT).show();
            return false;}
        return true;
    }
}
